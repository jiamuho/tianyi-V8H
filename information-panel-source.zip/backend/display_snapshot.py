"""Read-only presentation export. Never changes engine state or strategy."""
from __future__ import annotations
import json,math,os,tempfile
from datetime import datetime,timezone,timedelta
from pathlib import Path

def number(value):
    if value is None or isinstance(value,bool):return None
    try:
        value=float(value)
        return value if math.isfinite(value) else None
    except (TypeError,ValueError):return None

def make_snapshot(state,mark_prices,status_note,metrics=None):
    rows=[];unrealized=0.0;complete=True
    for symbol,p in state.get('positions',{}).items():
        ep=number(p.get('entry_price'));qty=number(p.get('qty'));mark=number(mark_prices.get(symbol));side=p.get('side')
        valid=ep is not None and ep>0 and qty is not None and mark is not None and mark>0 and side in ('Long','Short')
        pnl=((mark-ep)if side=='Long'else(ep-mark))*qty if valid else None
        move=((mark/ep-1)if side=='Long'else(1-mark/ep))*100 if valid else None
        if valid:unrealized+=pnl
        else:complete=False
        rows.append(dict(symbol=symbol,side=side,entry_price=ep,mark_price=mark,qty=qty,notional=number(p.get('notional')),eff_leverage=number(p.get('eff_leverage')),unrealized_pnl=pnl,price_move_pct=move,stop_loss_pct=number(p.get('stop_loss_pct')),breakeven_active=p.get('breakeven_active'),open_time_bj=p.get('open_time_bj')))
    cash=number(state.get('cash_balance'));initial=number(state.get('initial_capital'));equity=cash+unrealized if cash is not None and complete else None
    peak=number(state.get('peak_equity'));peak=max(peak or initial or 0,equity or 0)
    trades=state.get('closed_trades',[]);realized_values=[number(t.get('net_pnl'))for t in trades]
    account=dict(currency='USD',cash_balance=cash,equity=equity,unrealized_pnl=unrealized if complete else None,realized_pnl=sum(realized_values)if all(v is not None for v in realized_values)else None,return_pct=(equity/initial-1)*100 if equity is not None and initial and initial>0 else None,drawdown_pct=(equity/peak-1)*100 if equity is not None and peak>0 else None)
    # The integration passes the values already computed by the existing dashboard.
    if metrics and complete:
        for k in account:
            if k!='currency'and k in metrics:account[k]=number(metrics[k])
    heartbeat=state.get('last_heartbeat_bj');generated=datetime.now(timezone.utc).isoformat()
    if heartbeat:
        try:generated=datetime.strptime(heartbeat,'%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone(timedelta(hours=8))).isoformat()
        except (ValueError,TypeError):complete=False
    recent=[]
    for t in trades[-5:][::-1]:
        recent.append({k:(number(t.get(k))if k in ('id','net_pnl','hold_hours','notional')else t.get(k))for k in ('id','symbol','side','net_pnl','hold_hours','notional','close_time_bj','close_reason')})
    return dict(schema_version=1,kind='paper_trading',demo=False,generated_at=generated,status=dict(state='ok'if complete else'partial',note=status_note),account=account,positions=rows,recent_trades=recent)

def write_display_snapshot(state,mark_prices,status_note,output_path,metrics=None):
    payload=make_snapshot(state,mark_prices,status_note,metrics)
    data=json.dumps(payload,ensure_ascii=False,allow_nan=False,indent=2)+'\n'
    path=Path(output_path);path.parent.mkdir(parents=True,exist_ok=True);temp=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=path.parent,prefix='.display-',delete=False)as f:
            temp=Path(f.name);f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(temp,path)
    finally:
        if temp and temp.exists():temp.unlink()
    return payload
