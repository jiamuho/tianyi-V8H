"""模拟盘自动复盘与实时看板生成器。
每当平仓一笔交易，自动生成包含 MAE/MFE、触发原因与失血标签的单笔复盘；
每满 10 笔平仓自动输出阶段性 AI 参数诊断；每次心跳刷新 output/paper_trading_dashboard.md。
"""
from __future__ import annotations

from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data" / "paper_trader"
OUT_DIR = ROOT / "output"
REVIEWS_DIR = OUT_DIR / "paper_reviews"


def append_decision_event(time_bj: str, event_type: str, symbol: str, detail: str) -> None:
    """记录关键决策思考过程（开仓理由、保本激活、移动止盈上移、风控拦截、平仓）。"""
    REVIEWS_DIR.mkdir(parents=True, exist_ok=True)
    jpath = REVIEWS_DIR / "decision_journal.md"
    if not jpath.exists():
        jpath.write_text("# 模拟盘完整决策与思考日记\n\n| 时间 (北京时间) | 事件 | 品种 | 详情与逻辑依据 |\n|---|---|---|---|\n", encoding="utf-8")
    with jpath.open("a", encoding="utf-8") as f:
        f.write(f"| {time_bj} | `{event_type}` | {symbol} | {detail} |\n")


def classify_trade_tag(trade: dict) -> str:
    """为已平仓交易打上自动归因标签。"""
    reason = trade.get("close_reason", "")
    pnl = float(trade.get("net_pnl", 0.0))
    mfe = float(trade.get("mfe_pct", 0.0))
    mae = float(trade.get("mae_pct", 0.0))
    if "BREAKEVEN" in reason:
        return "AI保本护栏生效（成功锁住底线，未让浮盈变大亏）"
    if "TRAILING_TP" in reason:
        return "移动止盈落袋（在利润回吐35%阈值处自动锁定胜果）"
    if "HARD_SL" in reason:
        if mfe >= 1.5:
            return "冲高回落触发硬止损（曾浮盈但未达+2%保本线）"
        return "入场方向判断偏差（触发-5%硬止损截断尾部风险）"
    if pnl > 0:
        return "趋势兑现盈利"
    if mae < -3.0:
        return "高波动扛单亏损"
    return "常规止损"


def append_trade_review(trade: dict, all_trades: list[dict]) -> None:
    """平仓后追加单笔复盘流水，每满10笔生成阶段性AI诊断。"""
    REVIEWS_DIR.mkdir(parents=True, exist_ok=True)
    log_path = REVIEWS_DIR / "trade_log_reviews.md"
    if not log_path.exists():
        log_path.write_text("# 模拟盘逐笔自动复盘与修正日志\n\n", encoding="utf-8")

    tag = classify_trade_tag(trade)
    mfe = float(trade.get("mfe_pct", 0.0))
    move = float(trade.get("price_move_pct", 0.0))
    giveback = max(0.0, (mfe - move) / mfe * 100.0) if mfe > 0.5 else 0.0

    entry_ctx = trade.get("entry_context", {})
    block = [
        f"## 交易 #{trade['id']} | {trade['symbol']} {trade['side']} ({trade['close_time_bj']})",
        f"- **盈亏结果**：净盈亏 **`{trade['net_pnl']:+,.2f} USD`**（毛利 `{trade['gross_pnl']:+,.2f}`，手续费 `-{trade['fees']:,.2f}`，资金费 `{trade.get('funding_pnl', 0.0):+,.2f}`）",
        f"- **价格与路径**：开仓 `{trade['entry_price']:.4g}` → 平仓 `{trade['exit_price']:.4g}`（价格变化 `{move:+.2f}%`）｜ **MAE `{trade['mae_pct']:.2f}%`** ｜ **MFE `+{mfe:.2f}%`** ｜ 利润回吐率 `{giveback:.1f}%`",
        f"- **持仓与规模**：持仓 `{trade['hold_hours']:.2f}h` ｜ 名义规模 `${trade['notional']:,.0f}` ｜ 有效杠杆 `{trade['eff_leverage']:.2f}x` ｜ 时段 `{trade.get('session', '-')}`",
        f"- **入场信号快照**：24h涨跌 `{entry_ctx.get('ret_24h', 0.0):+.2f}%` ｜ 4H RSI `{entry_ctx.get('rsi4h', 0.0):.1f}` ｜ 4H ATR `{entry_ctx.get('atr_pct', 0.0):.2f}%`",
        f"- **平仓原因 & AI 归因**：`{trade['close_reason']}` → **{tag}**\n",
    ]

    # 每满 10 笔生成阶段性 AI 诊断建议
    n = len(all_trades)
    if n > 0 and n % 10 == 0:
        recent10 = pd.DataFrame(all_trades[-10:])
        wr10 = (recent10["net_pnl"] > 0).mean()
        pnl10 = recent10["net_pnl"].sum()
        avg_mfe10 = recent10["mfe_pct"].mean()
        avg_mae10 = recent10["mae_pct"].mean()
        sl_cnt = int(recent10["close_reason"].str.contains("HARD_SL", na=False).sum())
        be_cnt = int(recent10["close_reason"].str.contains("BREAKEVEN", na=False).sum())
        hints = []
        if wr10 < 0.45 and sl_cnt >= 5:
            hints.append("近10笔硬止损偏多，建议把入场 `ret24h` 阈值或 `RSI` 极值条件收紧（如多单 RSI<=28、空单 RSI>=75）。")
        if be_cnt >= 4 and pnl10 < 0:
            hints.append("保本触发频繁但净利偏弱，可考虑将保本激活线从 `+2.0%` 微调至 `+2.5%` 给波段更大呼吸空间。")
        if not hints:
            hints.append("近10笔风险收益结构健康，建议维持当前 `strategy_config.json` 参数继续样本积累。")
        block += [
            f"### [阶段性 AI 诊断报告（第 {n-9}–{n} 笔）]",
            f"- 近10笔胜率：`{wr10:.1%}` ｜ 净盈亏：`{pnl10:+,.2f} USD` ｜ 平均 MFE：`+{avg_mfe10:.2f}%` ｜ 平均 MAE：`{avg_mae10:.2f}%`",
            f"- 硬止损次数：`{sl_cnt}` ｜ 保本触发次数：`{be_cnt}`",
            f"- **AI 修正建议**：{' '.join(hints)}\n",
        ]

    with log_path.open("a", encoding="utf-8") as f:
        f.write("\n".join(block) + "\n")


def render_dashboard(state: dict, mark_prices: dict[str, float], status_note: str = "") -> None:
    """刷新全局实时模拟盘看板。"""
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    trades = state.get("closed_trades", [])
    positions = state.get("positions", {})
    cash = float(state.get("cash_balance", 10000.0))
    init_cap = float(state.get("initial_capital", 10000.0))

    unrealized_total = 0.0
    pos_rows = []
    for sym, p in positions.items():
        mp = float(mark_prices.get(sym, p["entry_price"]))
        qty = float(p["qty"])
        ep = float(p["entry_price"])
        upnl = (mp - ep) * qty if p["side"] == "Long" else (ep - mp) * qty
        unrealized_total += upnl
        move_pct = ((mp / ep - 1.0) if p["side"] == "Long" else (1.0 - mp / ep)) * 100.0
        pos_rows.append(
            f"| {sym} | {p['side']} | {ep:.4g} | {mp:.4g} | ${p['notional']:,.0f} | "
            f"{move_pct:+.2f}% | {upnl:+,.2f} | `{p['stop_loss_pct']:+.2f}%` | {'是' if p.get('breakeven_active') else '否'} |"
        )

    equity = cash + unrealized_total
    roi = (equity / init_cap - 1.0) * 100.0
    peak_eq = max(float(state.get("peak_equity", init_cap)), equity)
    mdd = (equity / peak_eq - 1.0) * 100.0

    n_trades = len(trades)
    if n_trades > 0:
        df = pd.DataFrame(trades)
        wins = df[df["net_pnl"] > 0]
        losses = df[df["net_pnl"] <= 0]
        wr = len(wins) / n_trades
        avg_w = wins["net_pnl"].mean() if len(wins) else 0.0
        avg_l = abs(losses["net_pnl"].mean()) if len(losses) else 0.0
        rr = (avg_w / avg_l) if avg_l > 0 else float("inf")
        realized = df["net_pnl"].sum()
    else:
        wr, rr, realized = 0.0, 0.0, 0.0

    lines = [
        "# $10,000 USD 实盘行情模拟盘实时看板",
        f"\n> 最后心跳（北京时间）：`{state.get('last_heartbeat_bj', '-')}` ｜ 状态：`{status_note or '运行中'}`\n",
        "## 一、账户核心净值",
        f"- **当前总权益**：**`${equity:,.2f} USD`**（总收益率：**`{roi:+.2f}%`**）",
        f"- **可用现金余额**：`${cash:,.2f}` ｜ **当前浮动盈亏**：`{unrealized_total:+,.2f}` ｜ **历史已实现净盈亏**：`{realized:+,.2f}`",
        f"- **历史峰值权益**：`${peak_eq:,.2f}` ｜ **当前回撤**：`{mdd:.2f}%`",
        f"- **已平仓统计**：`{n_trades}` 笔 ｜ 胜率：`{wr:.1%}` ｜ 盈亏比：`{rr:.2f}:1`",
        f"- **亏损冷却锁截止**：`{state.get('cooldown_until_bj') or '未触发'}`\n",
        "## 二、当前实时持仓",
    ]
    if pos_rows:
        lines += [
            "| 品种 | 方向 | 开仓价 | 最新标记价 | 名义规模 | 价格浮盈% | 浮盈亏(USD) | 当前止损线 | 已激活保本 |",
            "|---|---|---|---|---|---|---|---|---|",
            *pos_rows,
        ]
    else:
        lines.append("- 当前空仓，正在扫描 4H/1H 左侧极端偏离拐点信号。")

    if n_trades > 0:
        lines += [
            "\n## 三、最近 10 笔已平仓记录",
            "| # | 品种 | 方向 | 持仓(h) | 名义($) | 净盈亏(USD) | MAE% | MFE% | 平仓原因 |",
            "|---|---|---|---|---|---|---|---|---|",
        ]
        for t in trades[-10:][::-1]:
            lines.append(
                f"| {t['id']} | {t['symbol']} | {t['side']} | {t['hold_hours']:.1f} | "
                f"{t['notional']:,.0f} | **{t['net_pnl']:+,.2f}** | {t['mae_pct']:.2f}% | +{t['mfe_pct']:.2f}% | {t['close_reason']} |"
            )

    (OUT_DIR / "paper_trading_dashboard.md").write_text("\n".join(lines), encoding="utf-8")

    # Presentation-only export; failures must not stop the trading loop.
    try:
        from display_snapshot import write_display_snapshot
        write_display_snapshot(state, mark_prices, status_note,
            OUT_DIR / "display_snapshot.json", {
                "cash_balance": cash, "equity": equity,
                "unrealized_pnl": unrealized_total, "realized_pnl": float(realized),
                "return_pct": roi, "drawdown_pct": mdd,
            })
    except Exception as exc:
        print("[屏幕快照] 导出失败，交易流程继续:", type(exc).__name__)


