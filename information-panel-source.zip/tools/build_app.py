import pathlib,subprocess,zipfile,json,hashlib,datetime,sys
P=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(P/'backend'));from display_snapshot import make_snapshot
B=pathlib.Path(r'D:\kvm\device-audit\ZXV10-S100V8H\20261115-142138');R=B/'validation-20261115';J=B/'tools/jdk-25.0.5+8/bin';SDK=R/'android-build';JADX=B/'tools/lib/jadx-1.5.6-all.jar';R8=R/'runtime-tool/direct-home/r8.jar';O=P/'build/app';O.mkdir(parents=True,exist_ok=True)
def run(args):
 p=subprocess.run(list(map(str,args)),capture_output=True,env={**__import__('os').environ,'JAVA_TOOL_OPTIONS':'-Dfile.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -Dsun.stderr.encoding=UTF-8'})
 if p.returncode:raise RuntimeError((p.stdout+p.stderr).decode('utf-8','replace'))
 return p.stdout.decode('utf-8','replace')
classes=O/'classes';dex=O/'dex';sign=O/'sign';classes.mkdir(exist_ok=True);dex.mkdir(exist_ok=True);sign.mkdir(exist_ok=True)
run([J/'javac.exe','--release','8','-encoding','UTF-8','-cp',SDK/'android-28.jar','-d',classes,*(P/'android/src').rglob('*.java')]);run([J/'java.exe','-cp',R8,'com.android.tools.r8.D8','--min-api','28','--lib',SDK/'android-28.jar','--output',dex,*classes.rglob('*.class')])
res=O/'res.zip';unsigned=O/'unsigned.apk';apk=P/'build/zxv10-panel.apk';run([SDK/'aapt2.exe','compile','--dir',P/'android/res','-o',res]);run([SDK/'aapt2.exe','link','-I',SDK/'android-28.jar','--manifest',P/'android/AndroidManifest.xml','-o',unsigned,'--min-sdk-version','28','--target-sdk-version','28','--auto-add-overlay','-R',res])
demo=make_snapshot({'initial_capital':10000,'cash_balance':10120,'peak_equity':10200,'last_heartbeat_bj':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y-%m-%d %H:%M:%S'),'positions':{'DEMO-LONG':{'side':'Long','entry_price':100,'qty':2,'notional':200,'stop_loss_pct':-5,'breakeven_active':False},'DEMO-SHORT':{'side':'Short','entry_price':50,'qty':3,'notional':150,'stop_loss_pct':.25,'breakeven_active':True}},'closed_trades':[{'id':1,'symbol':'DEMO-CLOSED','net_pnl':12.5,'close_time_bj':'示例记录'}]}, {'DEMO-LONG':105,'DEMO-SHORT':48},'仅演示布局，非真实持仓');demo['demo']=True
demo['btc_macro']={'schema_version':1,'kind':'btc_market','generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':{'state':'ok','note':'演示数据'},'market':{'coinbase_last':64280,'coinbase_premium_pct':-.064,'funding_rate_pct':.0049,'fng_value':24},'signals':{'verdict':'未到现货买入区间 · 维持观望','left_hit_now':[],'left_hit_24h':[],'right_locks':{'price_above_200w':False,'coinbase_premium_positive':False,'funding_safe':True}}}
web=P/'web2'
javascript=(web/'app.js').read_text(encoding='utf-8')
startup="if (!within(state.simAbsolute)) state.overrideEnd = state.simAbsolute + state.config.nightMinutes;"
assert startup in javascript
javascript=javascript[:javascript.index(startup)]+(P/'android/web2-adapter.js').read_text(encoding='utf-8')
with zipfile.ZipFile(unsigned,'a',zipfile.ZIP_DEFLATED)as z:
 z.write(dex/'classes.dex','classes.dex');z.writestr('assets/display-demo.json',json.dumps(demo,ensure_ascii=False))
 for name in ['styles.css','favicon.svg']:z.write(web/name,'assets/panel/'+name)
 z.writestr('assets/panel/touch-settings.css',(web/'touch-settings.css').read_text(encoding='utf-8')+'\n'+(P/'android/app-palette.css').read_text(encoding='utf-8'))
 z.writestr('assets/panel/index.html',(web/'index.html').read_text(encoding='utf-8').replace(' type="module"',''))
 z.writestr('assets/panel/app.js',javascript)
run([J/'javac.exe','-cp',JADX,'-d',sign,R/'SignProbe.java',R/'VerifyApk.java']);cp=str(sign)+';'+str(JADX);run([J/'java.exe','-cp',cp,'SignProbe',R/'homebridge-build/homebridge-signing-key.p12',unsigned,apk]);verification=run([J/'java.exe','-cp',cp,'VerifyApk',apk]);assert 'Android28Verified=true'in verification
(O/'verification.txt').write_text(verification,encoding='utf-8');(P/'build/app.json').write_text(json.dumps({'apk':str(apk),'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'bytes':apk.stat().st_size,'version':11,'signed':True},indent=2),encoding='utf-8');print('APP_BUILT '+str(apk))
