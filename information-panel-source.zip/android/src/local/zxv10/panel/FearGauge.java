package local.zxv10.panel;
import android.content.*;import android.graphics.*;import android.view.View;
final class FearGauge extends View {
 final Paint p=new Paint(3);final float value;FearGauge(Context c,float v){super(c);value=v;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
 protected void onDraw(Canvas canvas){super.onDraw(canvas);float w=getWidth(),h=getHeight(),cx=w/2,cy=h/2,r=Math.min(w,h)/2-8;RectF arc=new RectF(cx-r,cy-r,cx+r,cy+r);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(6);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(Ui.BORDER);canvas.drawArc(arc,135,270,false,p);boolean valid=value>=0&&value<=100&&!Float.isNaN(value);p.setColor(value<=25?Ui.AMBER:value>=75?Ui.MINT:Ui.MUTED);if(valid)canvas.drawArc(arc,135,270*value/100,false,p);p.setStyle(Paint.Style.FILL);p.setTypeface(Typeface.create("sans-serif-medium",0));p.setTextAlign(Paint.Align.CENTER);p.setTextSize(Ui.dp(getContext(),29));p.setColor(Ui.TEXT);canvas.drawText(valid?Integer.toString(Math.round(value)):"—",cx,cy+5,p);p.setTextSize(Ui.dp(getContext(),11));p.setColor(Ui.MUTED);canvas.drawText("恐惧 / 贪婪",cx,cy+Ui.dp(getContext(),23),p);}
}
