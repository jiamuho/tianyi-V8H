package local.zxv10.panel;

import android.content.*;
import android.os.*;
import android.webkit.*;
import android.widget.FrameLayout;
import org.json.*;
import java.io.*;
import java.util.concurrent.*;

/** Bundled web2 UI; networking, credentials and power remain in native code. */
public final class WebDashboard {
 final Context c; final Runnable exit; final FrameLayout root; final WebView web;
 final Handler handler=new Handler(Looper.getMainLooper());
 final ExecutorService worker=Executors.newSingleThreadExecutor();
 volatile JSONObject power=new JSONObject(); boolean alive=true,ready=false;
 final Runnable ticker=new Runnable(){public void run(){if(!alive)return;render();handler.postDelayed(this,5000);}};
 public WebDashboard(Context context,Runnable leave){
  c=context;exit=leave;root=new FrameLayout(c);root.setBackgroundColor(0xff090b0e);
  web=new WebView(c);root.addView(web,new FrameLayout.LayoutParams(-1,-1));
  WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
  s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  s.setSaveFormData(false);s.setMediaPlaybackRequiresUserGesture(true);
  web.setImportantForAutofill(android.view.View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
  web.addJavascriptInterface(new Bridge(),"NativePanel");
  web.setWebViewClient(new WebViewClient(){
   public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return true;}
   public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest r){
    String path=r.getUrl().getPath();
    if("https".equals(r.getUrl().getScheme())&&"panel.local".equals(r.getUrl().getHost())&&path!=null&&path.matches("/(index\\.html|styles\\.css|touch-settings\\.css|app\\.js|favicon\\.svg)"))try{
     String mime=path.endsWith("css")?"text/css":path.endsWith("js")?"application/javascript":path.endsWith("svg")?"image/svg+xml":"text/html";
     return new WebResourceResponse(mime,"UTF-8",c.getAssets().open("panel"+path));
    }catch(Exception ignored){}
    return new WebResourceResponse("text/plain","UTF-8",new ByteArrayInputStream(new byte[0]));
   }
   public void onPageFinished(WebView v,String url){ready=true;render();}
  });
  web.loadUrl("https://panel.local/index.html");handler.postDelayed(ticker,1000);
 }
 void js(String script){handler.post(()->{if(alive&&ready)web.evaluateJavascript(script,null);});}
 void message(String text){js("toast("+JSONObject.quote(text)+")");}
 public void render(){if(!alive)return;worker.execute(()->{try{power=PowerClient.op("STATUS");}catch(Exception ignored){}js("nativeReceive("+new Bridge().state()+")");});}
 public void stop(){alive=false;handler.removeCallbacksAndMessages(null);worker.shutdownNow();web.removeJavascriptInterface("NativePanel");web.stopLoading();web.destroy();}
 public boolean closeOverlay(){js("nativeBack()");return true;}
 final class Bridge {
  @JavascriptInterface public String state(){try{
   JSONObject o=new JSONObject();o.put("snapshot",Store.snapshot(c));o.put("power",power);
   o.put("layout",new JSONObject(Store.prefs(c).getString("web2Layout","{}")));
   o.put("hasToken",Store.hasToken(c));o.put("demo",Store.prefs(c).getBoolean("demo",false));o.put("brightness",Store.prefs(c).getInt("dreamBrightness",35));
   o.put("syncStatus",Store.prefs(c).getString("syncStatus","尚未配置连接"));o.put("dream",c instanceof android.service.dreams.DreamService);
   return o.toString();
  }catch(Exception e){return "{}";}}
  @JavascriptInterface public void save(String raw,String section,String token){worker.execute(()->{try{
   JSONObject cfg=new JSONObject(raw);
   if("screen".equals(section)){
    JSONObject p=Schedule.defaults();p.put("windows",cfg.getJSONArray("windows"));p.put("nightMinutes",cfg.getInt("nightMinutes"));p.put("idleSeconds",cfg.getInt("idleSeconds"));Schedule.validate(p);
    int brightness=cfg.getInt("brightness");if(brightness<15||brightness>70)throw new Exception("亮度范围无效");
    PowerClient.request(new JSONObject().put("op","SET_CONFIG").put("config",p));
    PowerClient.op(cfg.optBoolean("powerEnabled")?"ENABLE":"DISABLE");
    Store.prefs(c).edit().putInt("idleSeconds",p.getInt("idleSeconds")).putInt("dreamBrightness",brightness).apply();
    Intent i=new Intent(c,ControlService.class);i.putExtra("applyDream",true);c.startForegroundService(i);
   }else if("data".equals(section)){
    if(!token.isEmpty())Store.token(c,token);
    Store.prefs(c).edit().putBoolean("demo",cfg.optBoolean("demo")).remove("etag").remove("retryAt").putBoolean("syncReady",false).apply();ControlService.start(c,true);
   }else if(!"layout".equals(section)&&!"appearance".equals(section))throw new Exception("设置类别无效");
   String tone=cfg.optString("tone","soft");if(!tone.equals("standard")&&!tone.equals("soft")&&!tone.equals("night"))throw new Exception("显示风格无效");
   JSONObject layout=new JSONObject();layout.put("tone",tone);layout.put("modules",cfg.getJSONArray("modules"));layout.put("fontScale",cfg.optDouble("fontScale",1));layout.put("hidden",cfg.optBoolean("hidden"));
   Store.prefs(c).edit().putString("web2Layout",layout.toString()).apply();
   message("设置已保存");render();
  }catch(Exception e){message("未能保存："+(e.getMessage()==null?"设备服务未就绪":e.getMessage()));render();}});}
  @JavascriptInterface public void action(String name){
   if("home".equals(name)){handler.post(()->{Intent i=c.getPackageManager().getLaunchIntentForPackage("app.orchard.tv");if(i!=null){i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);c.startActivity(i);exit.run();}else message("Aerial 暂不可用");});return;}
   if("exit".equals(name)){handler.post(exit);return;}
   worker.execute(()->{try{
    if("refresh".equals(name)){ControlService.start(c,true);message("正在检查仓库");}
    else if("disable".equals(name)){PowerClient.op("DISABLE");message("屏幕管理已停止");}
    else if("clear-token".equals(name)){Store.token(c,"");message("本机令牌已清除");}
    else return;render();
   }catch(Exception e){message("操作未完成，请检查设备服务");}});
  }
 }
}
