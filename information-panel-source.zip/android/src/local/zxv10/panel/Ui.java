package local.zxv10.panel;
import android.content.*;import android.content.res.ColorStateList;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;
final class Ui {
 static final int BG=0xff0B1218,CARD=0xff14212B,BORDER=0xff24343E,TEXT=0xffF0F5F5,MUTED=0xff93A7AD,MINT=0xff8CE2CB,AMBER=0xffE8BD85,CORAL=0xffFFAC9C;
 static int dp(Context c,float n){return(int)(c.getResources().getDisplayMetrics().density*n+.5f);}
 static GradientDrawable background(Context c,int color,int radius,boolean border){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(c,radius));if(border)g.setStroke(dp(c,1),BORDER);return g;}
 static TextView text(Context c,String s,int sp,int color){TextView t=new TextView(c);t.setText(s);t.setTextSize(sp);t.setTextColor(color);t.setFontFeatureSettings("tnum");t.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));t.setIncludeFontPadding(false);return t;}
 static TextView button(Context c,String s,boolean primary,Runnable action){TextView t=text(c,s,16,primary?0xff102820:TEXT);t.setGravity(Gravity.CENTER);t.setFocusable(true);t.setContentDescription(s);GradientDrawable bg=background(c,primary?MINT:0xff21323C,12,false);t.setBackground(new RippleDrawable(ColorStateList.valueOf(0x22ffffff),bg,null));t.setPadding(dp(c,18),dp(c,12),dp(c,18),dp(c,12));t.setOnClickListener(v->action.run());return t;}
 static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);return l;}
 static LinearLayout row(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
 static void gap(LinearLayout l,int dp){View v=new View(l.getContext());l.addView(v,new LinearLayout.LayoutParams(1,Ui.dp(l.getContext(),dp)));}
 static void addWeighted(LinearLayout row,View v,float weight){row.addView(v,new LinearLayout.LayoutParams(0,-1,weight));}
 static TextView pill(Context c,String s,int ink,int fill){TextView t=text(c,s,13,ink);t.setPadding(dp(c,12),dp(c,7),dp(c,12),dp(c,7));t.setBackground(background(c,fill,30,false));return t;}
 static LinearLayout card(Context c,int fill){LinearLayout l=column(c);l.setPadding(dp(c,24),dp(c,22),dp(c,24),dp(c,22));l.setBackground(background(c,fill,24,true));return l;}
 static void divider(LinearLayout l){View v=new View(l.getContext());v.setBackgroundColor(BORDER);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(l.getContext(),1));p.setMargins(0,dp(l.getContext(),18),0,dp(l.getContext(),18));l.addView(v,p);}
}
