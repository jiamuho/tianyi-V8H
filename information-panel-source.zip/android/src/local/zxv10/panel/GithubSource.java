package local.zxv10.panel;
import android.content.*;import java.net.*;import java.io.*;import org.json.*;
public final class GithubSource {
 public static synchronized void refresh(Context c,boolean manual){
  android.content.SharedPreferences p=Store.prefs(c);long now=System.currentTimeMillis();if(now<p.getLong("retryAt",0)){return;}
  if(p.getBoolean("demo",false)){p.edit().putBoolean("syncReady",false).putString("syncStatus","演示数据 · 未请求真实仓库").apply();return;}
  if(!Store.hasToken(c)){p.edit().putBoolean("syncReady",false).putString("syncStatus","尚未配置仓库只读令牌").apply();return;}
  if(!manual&&now-p.getLong("lastAttempt",0)<60000)return;p.edit().putLong("lastAttempt",now).apply();HttpURLConnection h=null;
  try{
   URL url=new URL("https://api.github.com/repos/"+Store.REPO+"/contents/display_snapshot.json?ref=main");String token=Store.token(c);
   for(int i=0;i<3;i++){h=(HttpURLConnection)url.openConnection();h.setInstanceFollowRedirects(false);h.setConnectTimeout(10000);h.setReadTimeout(15000);h.setRequestProperty("Authorization","Bearer "+token);h.setRequestProperty("Accept","application/vnd.github.raw+json");h.setRequestProperty("User-Agent","ZXV10-Panel/1.0");String etag=p.getString("etag","");if(!etag.isEmpty())h.setRequestProperty("If-None-Match",etag);
    int code=h.getResponseCode();if(code==301||code==302||code==307||code==308){URL to=new URL(url,h.getHeaderField("Location"));if(!"https".equals(to.getProtocol())||!"api.github.com".equals(to.getHost()))throw new IOException("拒绝向其他站点转发凭据");h.disconnect();h=null;url=to;continue;}
    if(code==304){p.edit().putBoolean("syncReady",true).putString("syncStatus","已检查 · 数据未变化").putLong("lastChecked",now).apply();return;}
    if(code==401){p.edit().putBoolean("syncReady",false).putString("syncStatus","令牌失效，请重新配置").putLong("retryAt",now+300000).apply();return;}
    if(code==403||code==429){long wait=60000;try{String r=h.getHeaderField("Retry-After");if(r!=null)wait=Math.max(wait,Long.parseLong(r)*1000);if("0".equals(h.getHeaderField("X-RateLimit-Remaining")))wait=Math.max(wait,Long.parseLong(h.getHeaderField("X-RateLimit-Reset"))*1000-now);}catch(Exception ignored){}p.edit().putLong("retryAt",now+wait).putBoolean("syncReady",false).putString("syncStatus","访问受限或达到请求限额，请检查权限并稍后重试").apply();return;}
    if(code==404)throw new IOException("未读到展示文件，请检查令牌权限及服务器是否已发布快照");if(code!=200)throw new IOException("GitHub 返回 "+code);
    String raw;try(InputStream in=h.getInputStream()){raw=Store.read(in);}Store.cache(c,raw);String tag=h.getHeaderField("ETag");p.edit().putString("etag",tag==null?"":tag).putBoolean("syncReady",true).putString("syncStatus","同步成功").putLong("lastChecked",now).remove("retryAt").apply();return;
   }throw new IOException("重定向次数过多");
  }catch(Exception e){String message=e.getMessage();p.edit().putBoolean("syncReady",false).putString("syncStatus",message==null?"网络请求失败，保留上次数据":message).apply();}finally{if(h!=null)h.disconnect();}
 }
}
