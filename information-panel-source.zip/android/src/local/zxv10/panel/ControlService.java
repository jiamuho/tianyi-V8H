package local.zxv10.panel;
import android.app.*;import android.content.*;import android.os.*;import android.net.Uri;import org.json.JSONObject;
public final class ControlService extends Service {
 private volatile boolean alive,manual,applyDream,reschedule;private final Object signal=new Object();
 public void onCreate(){super.onCreate();NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);n.createNotificationChannel(new NotificationChannel("panel","信息板服务",NotificationManager.IMPORTANCE_LOW));PendingIntent p=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT);startForeground(148,new Notification.Builder(this,"panel").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("智屏信息板").setContentText("持仓同步与屏幕管理").setContentIntent(p).build());}
 public int onStartCommand(Intent i,int flags,int id){
  if(i!=null){if(i.getBooleanExtra("refresh",false))manual=true;if(i.getBooleanExtra("applyDream",false))applyDream=true;if(i.getBooleanExtra("reschedule",false))reschedule=true;if(i.getBooleanExtra("runSelfTest",false))new Thread(()->PanelSelfTest.run(this),"PanelSelfTest").start();}
  if(!alive){alive=true;new Thread(()->work(),"PanelControl").start();}else synchronized(signal){signal.notifyAll();}return START_STICKY;
 }
 private void work(){long retry=0;while(alive){try{
  try{JSONObject s=PowerClient.op("STATUS");boolean desired=s.getJSONObject("config").optBoolean("enabled");if(desired&&(applyDream||(s.optBoolean("enabled")&&!s.optBoolean("dreamApplied"))))PowerClient.op("APPLY_DREAM");applyDream=false;if(reschedule){PowerClient.op("RESCHEDULE");reschedule=false;}}
  catch(Exception missing){if(SystemClock.elapsedRealtime()-retry>10000){retry=SystemClock.elapsedRealtime();Bundle b=new Bundle();b.putString("jniServiceSystemCmd","/system/bin/sh /data/local/codex-screen/start >/dev/null 2>&1 </dev/null &");getContentResolver().call(Uri.parse("content://com.android.zshd.deviceinfo/device_info"),"DEV_QUERY",null,b);}}
  boolean m=manual;manual=false;GithubSource.refresh(this,m);
 }catch(Exception e){Store.prefs(this).edit().putString("syncStatus","等待设备服务就绪").apply();}synchronized(signal){try{signal.wait(5000);}catch(Exception ignored){}}}}
 public void onDestroy(){alive=false;synchronized(signal){signal.notifyAll();}super.onDestroy();}public IBinder onBind(Intent i){return null;}
 public static void start(Context c,boolean refresh){Intent i=new Intent(c,ControlService.class);i.putExtra("refresh",refresh);c.startForegroundService(i);}
}
