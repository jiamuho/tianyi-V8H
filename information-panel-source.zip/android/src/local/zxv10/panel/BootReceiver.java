package local.zxv10.panel;
import android.content.*;
public final class BootReceiver extends BroadcastReceiver {public void onReceive(Context c,Intent i){Intent s=new Intent(c,ControlService.class);String a=i.getAction();if(Intent.ACTION_TIME_CHANGED.equals(a)||Intent.ACTION_TIMEZONE_CHANGED.equals(a))s.putExtra("reschedule",true);c.startForegroundService(s);}}
