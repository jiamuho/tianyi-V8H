package local.zxv10.panel;
import android.net.*;import org.json.*;import java.io.*;
public final class PowerClient {
 public static JSONObject request(JSONObject r)throws Exception{LocalSocket s=new LocalSocket();try{s.connect(new LocalSocketAddress("/data/local/codex-screen/control.sock",LocalSocketAddress.Namespace.FILESYSTEM));s.setSoTimeout(15000);s.getOutputStream().write((r.toString()+"\n").getBytes("UTF-8"));String result=new BufferedReader(new InputStreamReader(s.getInputStream())).readLine();JSONObject o=new JSONObject(result);if(!o.optBoolean("ok"))throw new IOException(o.optString("error","屏幕控制失败"));return o;}finally{s.close();}}
 public static JSONObject op(String s)throws Exception{JSONObject o=new JSONObject();o.put("op",s);return request(o);}
}
