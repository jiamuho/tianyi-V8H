package local.zxv10.panel;
import java.util.*;
import org.json.*;
/** Calendar-based weekly intervals, including overnight intervals. */
public final class Schedule {
 public static JSONObject defaults()throws Exception{
  JSONObject c=new JSONObject();c.put("enabled",false);c.put("zone","Asia/Shanghai");c.put("nightMinutes",10);c.put("idleSeconds",120);JSONArray a=new JSONArray();
  for(int d=1;d<=7;d++){JSONObject w=new JSONObject();w.put("day",d);w.put("start","07:00");w.put("end","23:00");w.put("enabled",true);a.put(w);}c.put("windows",a);return c;
 }
 public static void validate(JSONObject c)throws Exception{
  if(!"Asia/Shanghai".equals(c.getString("zone")))throw new Exception("仅支持北京时间");
  int n=c.getInt("nightMinutes"),idle=c.getInt("idleSeconds");if(n<1||n>120||idle<30||idle>3600)throw new Exception("时间范围无效");
  JSONArray a=c.getJSONArray("windows");if(a.length()!=7)throw new Exception("需要七天时间表");boolean[] seen=new boolean[8];
  for(int i=0;i<a.length();i++){JSONObject w=a.getJSONObject(i);int d=w.getInt("day");if(d<1||d>7||seen[d])throw new Exception("重复星期");seen[d]=true;minute(w.getString("start"));minute(w.getString("end"));if(w.getString("start").equals(w.getString("end")))throw new Exception("开始和结束不能相同");}
 }
 public static int minute(String s)throws Exception{if(!s.matches("[0-2][0-9]:[0-5][0-9]"))throw new Exception("请输入 HH:mm");int h=Integer.parseInt(s.substring(0,2));if(h>23)throw new Exception("小时无效");return h*60+Integer.parseInt(s.substring(3));}
 private static Calendar day(long now,int offset){Calendar c=Calendar.getInstance(TimeZone.getTimeZone("Asia/Shanghai"));c.setTimeInMillis(now);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);c.add(Calendar.DAY_OF_MONTH,offset);return c;}
 private static long at(Calendar d,int m){Calendar c=(Calendar)d.clone();c.set(Calendar.HOUR_OF_DAY,m/60);c.set(Calendar.MINUTE,m%60);return c.getTimeInMillis();}
 public static boolean within(JSONObject cfg,long now)throws Exception{
  JSONArray a=cfg.getJSONArray("windows");for(int off=-1;off<=0;off++){Calendar d=day(now,off);int dow=(d.get(Calendar.DAY_OF_WEEK)+5)%7+1;
   for(int i=0;i<a.length();i++){JSONObject w=a.getJSONObject(i);if(w.getInt("day")!=dow||!w.optBoolean("enabled",true))continue;int start=minute(w.getString("start")),end=minute(w.getString("end"));long s=at(d,start);Calendar e=(Calendar)d.clone();if(end<=start)e.add(Calendar.DAY_OF_MONTH,1);long t=at(e,end);if(now>=s&&now<t)return true;}
  }return false;
 }
 public static long next(JSONObject cfg,long now)throws Exception{
  long result=Long.MAX_VALUE;JSONArray a=cfg.getJSONArray("windows");for(int off=-1;off<=8;off++){Calendar d=day(now,off);int dow=(d.get(Calendar.DAY_OF_WEEK)+5)%7+1;
   for(int i=0;i<a.length();i++){JSONObject w=a.getJSONObject(i);if(w.getInt("day")!=dow||!w.optBoolean("enabled",true))continue;int s=minute(w.getString("start")),e=minute(w.getString("end"));Calendar ed=(Calendar)d.clone();if(e<=s)ed.add(Calendar.DAY_OF_MONTH,1);long[] candidates={at(d,s),at(ed,e)};for(long t:candidates)if(t>now&&within(cfg,t-1)!=within(cfg,t))result=Math.min(result,t);}
  }return result==Long.MAX_VALUE?0:result;
 }
}
