package local.zxv10.panel;
import org.json.*;import java.time.*;import java.util.*;
/** Presentation of the producer's verdict only; no client-side trading strategy. */
final class MarketModel {
 final JSONObject root,macro,market,signals,locks;final String verdict;final boolean stale,missing,partial;final long time;
 MarketModel(JSONObject r){root=r;macro=r==null?null:r.optJSONObject("btc_macro");market=macro==null?null:macro.optJSONObject("market");signals=macro==null?null:macro.optJSONObject("signals");locks=signals==null?null:signals.optJSONObject("right_locks");verdict=signals==null?"":signals.optString("verdict","");long stamp=0;try{stamp=OffsetDateTime.parse(macro.getString("generated_at")).toInstant().toEpochMilli();}catch(Exception ignored){}time=stamp;missing=signals==null||verdict.isEmpty();long age=System.currentTimeMillis()-stamp;stale=stamp==0||age>900000||age< -300000;partial=macro==null||macro.optJSONObject("status")==null||!"ok".equals(macro.optJSONObject("status").optString("state"));}
 String decision(){if(missing)return"等待买点数据";if(stale)return"买点待更新";if(partial)return"信号尚不完整";return shortVerdict();}
 String shortVerdict(){if(verdict.startsWith("未到")||verdict.startsWith("未进入")||verdict.startsWith("维持观望"))return"等待买点";String first=verdict.split("[·（(\\n]",2)[0].trim();return first.isEmpty()?"查看买点信号":first;}
 boolean trigger(){if(missing||stale||partial)return false;if(verdict.startsWith("未")||verdict.startsWith("等待")||verdict.startsWith("观望"))return false;return verdict.contains("触发")||verdict.startsWith("进入")||verdict.startsWith("已进入")||verdict.startsWith("右侧确认");}
 int count(){int n=0;if(locks==null)return -1;for(String k:new String[]{"price_above_200w","coinbase_premium_positive","funding_safe"}){if(!(locks.opt(k)instanceof Boolean))return -1;if(locks.optBoolean(k))n++;}return n;}
 static String number(JSONObject o,String key,int decimals,boolean sign){if(o==null||!o.has(key)||o.isNull(key))return"—";double n=o.optDouble(key,Double.NaN);if(Double.isNaN(n)||Double.isInfinite(n))return"—";return String.format(Locale.US,(sign?"%+":"%")+",."+decimals+"f",n);}
 static String pct(JSONObject o,String key,int decimals){String s=number(o,key,decimals,true);return s.equals("—")?s:s+"%";}
 static String clock(long t){if(t<=0)return"尚无数据";java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("HH:mm",Locale.CHINA);f.setTimeZone(TimeZone.getTimeZone("Asia/Shanghai"));return f.format(new Date(t));}
}
