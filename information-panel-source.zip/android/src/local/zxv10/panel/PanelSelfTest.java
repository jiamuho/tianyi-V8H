package local.zxv10.panel;
import android.content.Context;import org.json.*;import java.io.*;
final class PanelSelfTest {
 static void check(boolean b,String name)throws Exception{if(!b)throw new Exception(name);}
 static void run(Context c){synchronized(GithubSource.class){runLocked(c);}}
 static void runLocked(Context c){JSONObject result=new JSONObject();File file=new File(c.getFilesDir(),"snapshot.json");byte[] previous=null;boolean existed=file.exists(),hadToken=Store.hasToken(c);try{
  if(existed)previous=java.nio.file.Files.readAllBytes(file.toPath());String raw;try(InputStream in=c.getAssets().open("display-demo.json")){raw=Store.read(in);}JSONObject demo=Store.validate(raw);check(demo.optBoolean("demo"),"demo label");check(Store.generated(demo)>0,"source timestamp");
  Store.cache(c,raw);boolean bad=false;try{Store.cache(c,"{invalid");}catch(Exception e){bad=true;}check(bad,"invalid JSON rejected");check(new String(java.nio.file.Files.readAllBytes(file.toPath()),"UTF-8").equals(raw),"invalid response preserves cache");
  JSONObject empty=new JSONObject(raw);empty.put("positions",new JSONArray());Store.validate(empty.toString());JSONObject wrong=new JSONObject(raw);wrong.put("schema_version",99);bad=false;try{Store.validate(wrong.toString());}catch(Exception e){bad=true;}check(bad,"schema version");
  if(!hadToken){String marker="local-keystore-test-not-a-real-token";Store.token(c,marker);check(Store.token(c).equals(marker),"keystore roundtrip");check(!Store.prefs(c).getString("token","").contains(marker),"no plaintext preferences");Store.token(c,"");result.put("keystore","passed");}else result.put("keystore","skipped: existing credential preserved");
  result.put("cacheAndSchema","passed");result.put("modules",Store.modules(c).length());result.put("ok",true);
 }catch(Exception e){try{result.put("ok",false);result.put("error",e.getClass().getSimpleName()+": "+e.getMessage());}catch(Exception ignored){}}finally{
  try{if(!hadToken)Store.token(c,"");if(existed&&previous!=null)java.nio.file.Files.write(file.toPath(),previous);else if(!existed)file.delete();try(FileOutputStream out=new FileOutputStream(new File(c.getFilesDir(),"selftest.json"))){out.write(result.toString().getBytes("UTF-8"));}}catch(Exception ignored){}
 }}
}
