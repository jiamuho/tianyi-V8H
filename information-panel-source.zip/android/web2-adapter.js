// Included only in the APK. The browser preview never loads this adapter.
let nativeState = {}, nativeSignature = '';
let nativePendingToken = '';
let nativePointerDown = false, nativePointerAt = 0, nativeRedrawTimer;
document.addEventListener('pointerdown',()=>{nativePointerDown=true;nativePointerAt=Date.now();},true);
for(const name of ['pointerup','pointercancel'])document.addEventListener(name,()=>{nativePointerDown=false;nativePointerAt=Date.now();},true);
function nativeSafeRender(){
  clearTimeout(nativeRedrawTimer);
  if(nativePointerDown||Date.now()-nativePointerAt<800){nativeRedrawTimer=setTimeout(nativeSafeRender,850);return;}
  if(state.page!=='settings'&&!overlay.innerHTML)render();
}
const nativeMenuRenderer = menu;
menu = function(){
  nativeMenuRenderer();
  if(nativeState.dream){
    const list=$('.control-actions');
    if(list)list.insertAdjacentHTML('beforeend','<button class="control-action" data-action="native-exit">'+icon('back')+'<span>退出屏保 · 返回之前界面</span></button>');
  }
};
const nativeDashboardRenderer = renderDashboard;
renderDashboard = function(){
  if(nativePointerDown){nativeRedrawTimer=setTimeout(nativeSafeRender,850);return;}
  nativeDashboardRenderer();
  for(const tile of document.querySelectorAll('.lock-tile')){
    const status=document.createElement('span');status.className='lock-condition';
    status.textContent=tile.classList.contains('on')?'✓ 已达成':tile.title.includes('未知')?'暂无数据':'— 未达成';
    tile.append(status);tile.setAttribute('aria-label',tile.title+'，'+status.textContent);
  }
  const source=$('.app-footer > span');
  if(source&&!nativeState.demo){
    const label=nativeState.hasToken ? '私人仓库 · '+(nativeState.syncStatus||'等待同步') : '本地缓存 · 尚未配置自动同步';
    source.innerHTML='<i class="source-led '+(nativeState.hasToken?'':'offline')+'"></i>'+esc(label)+(state.screensaver?' · 屏保':'');
  }
};
document.body.classList.add('native-app');
const nativeStyle = document.createElement('style');
nativeStyle.textContent = `.preview-toolbar,.preview-caption,.preview-footnote{display:none!important}.preview-workspace{padding:0;margin:0;max-width:none;width:100vw;height:100vh}.stage{border-radius:0;box-shadow:none;max-width:none;margin:0}.native-app{overflow:hidden}`;
document.head.append(nativeStyle);
window.removeEventListener('resize',fit);
fit = function(){
  const scale=Math.min(innerWidth/1280,innerHeight/800);
  device.style.transform=`scale(${scale})`;
  $('#stage').style.width=`${1280*scale}px`;$('#stage').style.height=`${800*scale}px`;
};
window.addEventListener('resize',fit);
persist = function(){ NativePanel.save(JSON.stringify(state.config),'layout',''); };
refresh = async function(){toast('正在检查仓库…');NativePanel.action('refresh');};
updateCaption = function(){};
simulationLabel = function(){
  return nativeState.power?.enabled ? '屏幕管理运行中' : '屏幕管理未启用';
};
dataSettings = function(){
  const m=marketModel(data());
  return `<div class="data-settings-grid"><div class="settings-column">${settingsCard('私人仓库','仅此仓库 Contents: read 权限',`
    <div class="repo-name">jiamuho/aoying-paper-sync</div>
    <div class="connection-note">令牌经设备密钥加密保存，仅由原生网络组件读取；网页无法读回令牌。</div>
    <div class="form-field"><label for="native-token">访问令牌</label><input id="native-token" type="password" autocomplete="off" value="${esc(nativePendingToken)}" placeholder="${nativeState.hasToken?'已加密保存 · 留空保持原值':'输入专用只读令牌'}"></div>
    <div class="settings-action-row"><button class="secondary-button" data-action="native-clear-token">清除本机令牌</button><button class="secondary-button" data-action="refresh">刷新数据</button></div>`)}
    ${settingsCard('演示模式','演示内容有明确标识，不代表真实持仓',`<div class="settings-row"><div>使用演示数据</div>${switchHTML('demo',Boolean(state.draft?.demo??nativeState.demo),'使用演示数据')}</div>`)}</div>
    <div class="settings-column">${settingsCard('数据状态','',`<div class="settings-state-block">${esc(nativeState.syncStatus||'等待连接')}</div><div class="settings-state-small">持仓快照 ${time(data()?.generated_at)}<br>宏观快照 ${time(m.macro?.generated_at)}<br>检查频率 每 5 分钟<br>断网保留上次有效快照，较旧数据有明确标识。</div>`)}</div></div>`;
};
saveSettings = function(){
  const c=state.draft;
  const token=$('#native-token')?.value.trim()||nativePendingToken;
  c.demo=$('[data-setting="demo"]')?.checked??Boolean(nativeState.demo);
  NativePanel.save(JSON.stringify(c),state.settingsTab,token);
  if(state.settingsTab==='data'){nativePendingToken='';if($('#native-token'))$('#native-token').value='';}
  if(['layout','appearance'].includes(state.settingsTab)){state.config=clone(c);device.style.setProperty('--type-scale',String(c.fontScale));}
};
window.nativeReceive = function(payload){
  nativeState=payload;
  const signature=JSON.stringify(payload);
  if(signature===nativeSignature)return;
  nativeSignature=signature;
  state.raw=payload.snapshot||null;state.scenario='live';
  const p=payload.power?.config||{};
  state.config={...state.config,...payload.layout};
  for(const k of ['windows','nightMinutes','idleSeconds'])if(p[k]!=null)state.config[k]=p[k];
  state.config.powerEnabled=Boolean(payload.power?.enabled);
  state.config.demo=Boolean(payload.demo);
  state.config.brightness=payload.brightness??35;
  state.screensaver=Boolean(payload.dream);
  if(state.page!=='settings')nativeSafeRender();
  else if(state.settingsTab==='data'){
    const status=$('.settings-state-block');
    if(status)status.textContent=payload.syncStatus||'等待连接';
    const info=$('.data-settings-grid > .settings-column:last-child .settings-state-small');
    if(info)info.innerHTML='持仓快照 '+esc(time(payload.snapshot?.generated_at))+'<br>宏观快照 '+esc(time(payload.snapshot?.btc_macro?.generated_at))+'<br>检查频率 每 5 分钟';
  }
};
// Intercept preview-only actions before the common delegated handler receives them.
document.addEventListener('click',event=>{
  const el=event.target.closest('[data-action]');if(!el)return;
  if(el.dataset.action==='settings-tab'&&$('#native-token'))nativePendingToken=$('#native-token').value.trim();
  if(['settings-back','home','native-exit'].includes(el.dataset.action))nativePendingToken='';
  const map={home:'home','native-exit':'exit','stop-management':'disable','native-clear-token':'clear-token'};
  const op=map[el.dataset.action];if(!op)return;
  event.stopImmediatePropagation();event.preventDefault();closeOverlay();
  if(op==='clear-token'){
    panel('清除本机令牌？','<p class="connection-note">缓存数据会保留；重新同步需要填写令牌。</p><button class="primary-button" data-action="native-confirm-clear">清除令牌</button>');return;
  }
  NativePanel.action(op);
},true);
document.addEventListener('click',event=>{
  if(event.target.closest('[data-action="native-confirm-clear"]')){nativePendingToken='';if($('#native-token'))$('#native-token').value='';closeOverlay();NativePanel.action('clear-token');}
});
window.nativeBack = function(){
  if(overlay.innerHTML)closeOverlay();
  else if(state.page==='settings'){nativePendingToken='';state.page='dashboard';state.draft=null;render();}
  else NativePanel.action('exit');
};
// Real sleeping, waking and idle dreaming are managed by Android and the root component.
state.config.powerEnabled=false;
window.nativeReceive(JSON.parse(NativePanel.state()));
fit();render();
