const $ = s => document.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const paths = {
  refresh: 'M20 7v5h-5M4 17v-5h5M6.1 8a7 7 0 0 1 11.6-2L20 9M4 15l2.3 3a7 7 0 0 0 11.6-2',
  settings: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8M9 3l1-1h4l1 3 3 1 3 1v4l-2 2v3l-2 3h-3l-2 2-3-2H6l-2-3v-3l-2-2V7l3-1 3-1Z',
  eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6',
  home: 'm3 10 9-7 9 7M5 9v12h5v-7h4v7h5V9',
  close: 'm6 6 12 12M6 18 18 6',
  back: 'm15 5-7 7 7 7',
  next: 'm9 5 7 7-7 7',
  up: 'm5 14 7-7 7 7',
  down: 'm5 10 7 7 7-7',
  check: 'm5 12 4 4L19 6',
  minus: 'M6 12h12',
  power: 'M12 2v10M6.5 5a9 9 0 1 0 11 0',
  moon: 'M20.8 13.1A9 9 0 0 1 10.9 3a9 9 0 1 0 9.9 10.1Z',
  signal: 'M4 19v-5M10 19V9M16 19V5M22 19V2',
  market: 'M3 19V5M3 19h18M6 14l4-5 4 3 7-8',
  positions: 'M4 7h16v13H4zM8 7V4h8v3M4 12h16M10 12v3h4v-3',
  account: 'M3 6h16v14H3zM3 6l13-3v3M15 11h7v5h-7z',
  trades: 'M5 5h14v15H5zM8 9h8M8 13h8M8 17h4',
  status: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20M12 7v6l4 2',
  copy: 'M8 8h13v13H8zM16 8V3H3v13h5',
  sun: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5',
  radar: 'M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0 -18 0M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0 -8 0M12 3v4M12 17v4M3 12h4M17 12h4'
};
const icon = (name, cls = '') => `<svg class="${cls}" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="${paths[name] || paths.status}"/></svg>`;

const modules = [
  { id: 'signal', title: '买点雷达', note: '买点信标、右侧确认与策略结论', enabled: true, span: 1 },
  { id: 'market', title: 'BTC 市场', note: '现货价格、24H区间与宏观流动性', enabled: true, span: 1 },
  { id: 'account', title: '模拟账户', note: '账户权益、收益与回撤概览', enabled: true, span: 1 },
  { id: 'positions', title: '当前持仓', note: '进行中的模拟仓位', enabled: true, span: 1 },
  { id: 'trades', title: '最近平仓', note: '最近三笔平仓记录', enabled: false, span: 1 },
  { id: 'status', title: '同步状态', note: '快照时间与连接状态', enabled: false, span: 1 }
];

const defaults = () => ({
  tone: 'soft',
  fontScale: 1,
  hidden: false,
  powerEnabled: true,
  idleSeconds: 120,
  nightMinutes: 10,
  brightness: 35,
  windows: Array.from({ length: 7 }, (_, i) => ({ day: i + 1, enabled: true, start: '07:00', end: '23:00' })),
  modules: structuredClone(modules)
});

function loadConfig() {
  try {
    const c = JSON.parse(localStorage.getItem('aoying-preview-v2'));
    if (!c) return defaults();
    const result = { ...defaults(), ...c };
    result.modules = (c.modules || modules)
      .filter(m => modules.some(x => x.id === m.id))
      .map(m => ({ ...modules.find(x => x.id === m.id), ...m }));
    if (!result.modules.length) result.modules = structuredClone(modules);
    if (!Array.isArray(result.windows) || result.windows.length !== 7) result.windows = defaults().windows;
    result.fontScale = [1, 1.12, 1.23].includes(Number(result.fontScale)) ? Number(result.fontScale) : 1;
    result.tone = ['standard','soft','night'].includes(result.tone) ? result.tone : 'soft';
    return result;
  } catch {
    return defaults();
  }
}

const realClockParts = () => {
  const p = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Shanghai', hour: '2-digit', minute: '2-digit', weekday: 'short' }).formatToParts(new Date());
  const get = t => p.find(x => x.type === t)?.value;
  return { day: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].indexOf(get('weekday')), minute: Number(get('hour')) * 60 + Number(get('minute')) };
};
const initialClock = realClockParts();

const state = {
  config: loadConfig(),
  draft: null,
  raw: null,
  imported: null,
  scenario: 'live',
  page: 'dashboard',
  settingsTab: 'screen',
  positionPage: 0,
  fit: true,
  screenOn: true,
  manualOff: false,
  overrideEnd: null,
  simAbsolute: initialClock.day * 1440 + initialClock.minute,
  screensaver: false,
  lastInteraction: Date.now(),
  gridScroll: 0
};

const app = $('#app'), device = $('#device'), overlay = $('#overlay-root');
let toastTimer;

function toast(message, error = false) {
  clearTimeout(toastTimer);
  const el = $('#toast');
  el.textContent = message;
  el.setAttribute('role', error ? 'alert' : 'status');
  el.classList.add('show');
  toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

function persist() {
  localStorage.setItem('aoying-preview-v2', JSON.stringify(state.config));
  $('#font-size').value = String(state.config.fontScale);
}

function num(v, dec = 2, signed = false) {
  if (typeof v !== 'number' || !Number.isFinite(v)) return '—';
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: dec,
    maximumFractionDigits: dec,
    signDisplay: signed ? 'always' : 'auto'
  }).format(v);
}

const money = (v, dec = 2, signed = false) => (state.config.hidden ? '••••' : num(v, dec, signed));
const pct = (v, dec = 2) => (typeof v === 'number' && Number.isFinite(v) ? num(v, dec, true) + '%' : '—');
const color = v => (typeof v === 'number' && v < 0 ? 'negative' : 'positive');
const time = t => {
  const d = new Date(t);
  return Number.isFinite(d.getTime())
    ? new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', hour: '2-digit', minute: '2-digit', hour12: false }).format(d)
    : '—';
};
const age = t => {
  const n = Date.parse(t);
  return Number.isFinite(n) ? Date.now() - n : Infinity;
};
const clone = v => structuredClone(v);

function validate(data) {
  if (!data || data.schema_version !== 1 || data.kind !== 'paper_trading' || typeof data.demo !== 'boolean' || !Number.isFinite(Date.parse(data.generated_at)) || !data.account || !Array.isArray(data.positions) || !Array.isArray(data.recent_trades)) {
    throw Error('请使用 schema_version 1 的完整展示快照');
  }
  if (data.positions.length > 1000) throw Error('持仓条目过多');
  const object = v => v !== null && typeof v === 'object' && !Array.isArray(v);
  if (!object(data.account) || !data.positions.every(object) || !data.recent_trades.every(object)) {
    throw Error('账户或交易条目格式错误');
  }
  if (data.btc_macro != null && (!object(data.btc_macro) ||
      (data.btc_macro.signals != null && !object(data.btc_macro.signals)) ||
      (data.btc_macro.market != null && !object(data.btc_macro.market)))) {
    throw Error('宏观快照格式错误');
  }
  return data;
}

function demoSnapshot(type) {
  const now = new Date().toISOString();
  const r = {
    schema_version: 1,
    kind: 'paper_trading',
    demo: true,
    generated_at: now,
    status: { state: 'ok', note: '网页演示' },
    account: {
      currency: 'USD',
      equity: 10386.2,
      cash_balance: 10200,
      unrealized_pnl: 186.2,
      realized_pnl: 200,
      return_pct: 3.86,
      drawdown_pct: -0.7
    },
    positions: [],
    recent_trades: [
      { id: 102, symbol: 'BTCUSDT', side: 'Long', net_pnl: 145, close_time_bj: '示例交易 23:02' },
      { id: 101, symbol: 'ETHUSDT', side: 'Short', net_pnl: 55, close_time_bj: '示例交易 18:40' }
    ],
    btc_macro: {
      schema_version: 1,
      kind: 'btc_daily_monitor',
      generated_at: now,
      status: { state: 'ok', note: '演示数据' },
      market: {
        coinbase_last: 64462.78,
        coinbase_24h_high: 65626.98,
        coinbase_24h_low: 63833.47,
        coinbase_vol_ratio_30d: 1.36,
        offshore_last: 64507.8,
        offshore_source: 'okx',
        coinbase_premium_pct: -0.0698,
        funding_rate_pct: 0.00494,
        stablecoin_total_b: 287.05,
        stablecoin_7d_chg_b: -4.173,
        stablecoin_7d_chg_pct: -1.433,
        fng_value: 18,
        fng_label: 'Extreme Fear'
      },
      signals: {
        verdict: '未到现货买入区间 · 维持观望（18%底仓锁死，82%现金留守SGOV）',
        left_hit_now: [],
        left_hit_24h: [],
        right_locks: {
          price_above_200w: false,
          coinbase_premium_positive: false,
          funding_safe: true
        }
      }
    }
  };
  if (type === 'buy') {
    r.btc_macro.signals.verdict = '右侧确认 · 现货买点已触发（演示：可分批建仓）';
    r.btc_macro.signals.right_locks = { price_above_200w: true, coinbase_premium_positive: true, funding_safe: true };
    r.btc_macro.market.coinbase_last = 68420.5;
    r.btc_macro.market.coinbase_24h_high = 68750.0;
    r.btc_macro.market.coinbase_24h_low = 65210.0;
    r.btc_macro.market.offshore_last = 68340.0;
    r.btc_macro.market.coinbase_premium_pct = 0.1178;
    r.btc_macro.market.stablecoin_7d_chg_b = 2.84;
    r.btc_macro.market.stablecoin_7d_chg_pct = 0.98;
    r.btc_macro.market.fng_value = 46;
    r.btc_macro.market.fng_label = 'Neutral';
    r.btc_macro.signals.left_hit_now = ['演示触发条件'];
  }
  if (type === 'positions') {
    r.positions = [
      { symbol: 'BTCUSDT', side: 'Long', entry_price: 64000, mark_price: 64462.78, qty: 0.2, notional: 12800, unrealized_pnl: 118.4, price_move_pct: 0.925 },
      { symbol: 'ETHUSDT', side: 'Short', entry_price: 1800, mark_price: 1768, qty: 2.5, notional: 4500, unrealized_pnl: 80, price_move_pct: 1.7778 },
      { symbol: 'SOLUSDT', side: 'Long', entry_price: 150, mark_price: 147.56, qty: 5, notional: 750, unrealized_pnl: -12.2, price_move_pct: -1.6267 }
    ];
  }
  if (type === 'stale') {
    r.generated_at = new Date(Date.now() - 3600000).toISOString();
    r.btc_macro.generated_at = r.generated_at;
    r.btc_macro.signals.verdict = '右侧确认 · 买点已触发（历史演示）';
  }
  if (type === 'offline') {
    r.generated_at = new Date(Date.now() - 120000).toISOString();
    r.btc_macro.generated_at = r.generated_at;
  }
  return r;
}

function data() {
  if (state.scenario === 'live') return state.raw;
  if (state.scenario === 'imported') return state.imported;
  if (state.scenario === 'empty') return null;
  return state.demoData;
}

function marketModel(r) {
  const macro = r?.btc_macro, signals = macro?.signals, market = macro?.market;
  const verdict = typeof signals?.verdict === 'string' ? signals.verdict : '';
  const elapsed = age(macro?.generated_at);
  const missing = !verdict;
  const expires = Date.parse(macro?.valid_until || "");
  const stale = !Number.isFinite(elapsed) || elapsed < -300000 || (Number.isFinite(expires) ? Date.now() > expires : elapsed > 86400000);
  const partial = macro?.status?.state !== 'ok' || r?.status?.state !== 'ok';
  const locks = signals?.right_locks;
  const keys = ['price_above_200w', 'coinbase_premium_positive', 'funding_safe'];
  const known = keys.every(k => typeof locks?.[k] === 'boolean');
  const count = known ? keys.filter(k => locks[k]).length : null;
  const negative = /未触发|尚未|未到|未进入|未确认|不满足|^(未|等待|观望|维持观望)/.test(verdict.trim());
  const trigger = !missing && !stale && !partial && !negative && (/触发/.test(verdict) || /^(进入|已进入|右侧确认)/.test(verdict));
  const short = negative ? '等待买点' : trigger ? '买点已触发' : verdict.split(/[·（(\n]/)[0].trim().slice(0, 12);
  const title = missing ? '等待信号' : stale ? '上次结论 · 待更新' : partial ? '信号不完整' : negative ? '等待买点' : trigger ? '买点已触发' : '信号待确认';
  const stateKey = missing ? 'empty' : stale || partial ? 'stale' : trigger ? 'buy' : 'wait';
  return { macro, signals, market, verdict, stale, missing, partial, locks, count, title, trigger, short, stateKey };
}

/* Custom Hardware-Grade Buy-Point Signal Beacon SVG */
function buySignalBeacon(stateKey) {
  if (stateKey === 'buy') {
    return `<svg class="beacon-svg" viewBox="0 0 64 64" fill="none" aria-label="买点已触发图标">
      <circle class="beacon-pulse" cx="32" cy="32" r="24" stroke="var(--mint)" stroke-width="1.5" opacity="0.65"/>
      <circle cx="32" cy="32" r="26" stroke="var(--mint)" stroke-width="1.5" stroke-dasharray="10 6" opacity="0.5"/>
      <circle cx="32" cy="32" r="18" fill="var(--mint)" fill-opacity="0.16" stroke="var(--mint)" stroke-width="2"/>
      <path d="M25 38 L39 24 M39 24 H29 M39 24 V34" stroke="var(--mint)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;
  }
  if (stateKey === 'wait') {
    return `<svg class="beacon-svg" viewBox="0 0 64 64" fill="none" aria-label="观望等待图标">
      <circle cx="32" cy="32" r="25" stroke="var(--amber)" stroke-width="1.5" stroke-opacity="0.35"/>
      <path d="M32 5v5M32 54v5M5 32h5M54 32h5" stroke="var(--amber)" stroke-width="1.75" stroke-linecap="round" stroke-opacity="0.65"/>
      <circle cx="32" cy="32" r="16" fill="var(--amber)" fill-opacity="0.1" stroke="var(--amber)" stroke-width="2"/>
      <path d="M24 32h16" stroke="var(--amber)" stroke-width="3" stroke-linecap="round"/>
      <circle cx="32" cy="32" r="3" fill="var(--amber)"/>
    </svg>`;
  }
  if (stateKey === 'stale') {
    return `<svg class="beacon-svg" viewBox="0 0 64 64" fill="none" aria-label="数据过期图标">
      <circle cx="32" cy="32" r="24" stroke="#7c8b9e" stroke-width="1.75" stroke-dasharray="5 5"/>
      <circle cx="32" cy="32" r="16" fill="#7c8b9e" fill-opacity="0.1" stroke="#7c8b9e" stroke-width="1.75"/>
      <path d="M32 23v11" stroke="var(--amber)" stroke-width="2.75" stroke-linecap="round"/>
      <circle cx="32" cy="40" r="1.8" fill="var(--amber)"/>
    </svg>`;
  }
  return `<svg class="beacon-svg" viewBox="0 0 64 64" fill="none" aria-label="等待连接图标">
    <circle cx="32" cy="32" r="24" stroke="#475569" stroke-width="1.5" stroke-dasharray="3 6"/>
    <circle cx="32" cy="32" r="14" stroke="#475569" stroke-width="1.5"/>
    <circle cx="32" cy="32" r="3.5" fill="var(--muted)"/>
  </svg>`;
}

function badge(text, type = '') {
  return `<span class="pill ${type}">${esc(text)}</span>`;
}

function cardStart(id, label, extra = '', cls = '') {
  return `<section class="app-card ${cls}" data-module="${id}"><div class="card-top"><div class="eyebrow">${label}</div>${extra}</div>`;
}

function lockTileIcon(key, on) {
  const stroke = on ? 'var(--mint)' : 'var(--muted)';
  if (key === 'price_above_200w') {
    return `<svg class="lock-tile-svg" viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <path d="M4 23l7.5-7.5 5.5 4.5L27 9" stroke="${stroke}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M21 9h6v6" stroke="${stroke}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;
  }
  if (key === 'coinbase_premium_positive') {
    return `<svg class="lock-tile-svg" viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <circle cx="16" cy="16" r="10.5" stroke="${stroke}" stroke-width="2.2"/>
      <path d="M16 10.5v11M19.5 13.2c0-1.2-1.5-2-3.5-2s-3.5.8-3.5 2 1.2 1.8 3.5 2.2 3.5 1 3.5 2.3-1.5 2.1-3.5 2.1-3.5-.9-3.5-2.1" stroke="${stroke}" stroke-width="2" stroke-linecap="round"/>
    </svg>`;
  }
  return `<svg class="lock-tile-svg" viewBox="0 0 32 32" fill="none" aria-hidden="true">
    <path d="M16 4.5 25.5 8.5v7c0 6.2-4 10.5-9.5 12.2C10.5 26 6.5 21.7 6.5 15.5v-7L16 4.5Z" stroke="${stroke}" stroke-width="2.2" stroke-linejoin="round"/>
    <path d="M12 16.2l2.8 2.8 5.5-5.8" stroke="${stroke}" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
}

function signalCard(r, m) {
  const tag = m.missing ? '待连接' : m.stale ? '上次结论' : m.partial ? '信号残缺' : m.trigger ? '买点触发' : '观望中';
  const kicker = m.missing ? 'OFFLINE · STANDBY' : m.stale ? 'STALE SNAPSHOT' : m.trigger ? 'SIGNAL · BUY ZONE' : 'SIGNAL · HOLD CASH';
  const lockItems = [
    ['price_above_200w', '200W均线'],
    ['coinbase_premium_positive', 'CB溢价'],
    ['funding_safe', '资金费率']
  ].map(([k, label]) => {
    const on = m.locks?.[k] === true;
    const known = typeof m.locks?.[k] === 'boolean';
    return `<div class="lock-tile ${on ? 'on' : ''}" title="${label}: ${known ? (on ? '已满足' : '未满足') : '未知'}">
      <span class="lock-tile-badge">${on ? icon('check') : icon('minus')}</span>
      ${lockTileIcon(k, on)}
      <span class="lock-tile-label">${label}</span>
    </div>`;
  }).join('');

  const hitNow = Array.isArray(m.signals?.left_hit_now) ? m.signals.left_hit_now.length : null;
  const hit24 = Array.isArray(m.signals?.left_hit_24h) ? m.signals.left_hit_24h.length : null;
  const postureMatch = m.verdict.match(/（([^）]+)）/);
  const conciseNote = m.missing
    ? '等待服务器快照'
    : m.stale
      ? `${esc(m.verdict)}（有效期已过）`
      : postureMatch
        ? esc(postureMatch[1])
        : esc(m.verdict.split(/[·\n]/).slice(0, 2).join(' · '));

  return cardStart('signal', 'BTC · 买点雷达', badge(tag, m.trigger ? 'pill-buy' : m.stale || m.missing ? 'pill-stale' : 'pill-wait'), `hero-card state-${m.stateKey}`) +
    `<div class="beacon-stage">
      <div class="beacon-wrap">${buySignalBeacon(m.stateKey)}</div>
      <div class="decision-block">
        <div class="decision-kicker">${kicker}</div>
        <div class="decision ${m.trigger ? 'status-buy' : m.stale || m.missing ? 'status-stale' : ''}">${esc(m.title)}</div>
        <div class="verdict-pill">${conciseNote}</div>
      </div>
    </div>
    <div class="locks-section">
      <div class="locks-header"><span>右侧确认</span><strong>${m.count ?? '—'} <span class="muted">/ 3</span></strong></div>
      <div class="locks-tiles">${lockItems}</div>
    </div>
    <div class="hero-bottom">
      <span>左侧 ${hitNow === null ? '—' : `${hitNow} 项`} (24H ${hit24 ?? '—'}) · ${time(m.macro?.generated_at)}</span>
      <button class="text-link" data-action="signal-details">详情 ${icon('next')}</button>
    </div></section>`;
}

function formatPriceHTML(p) {
  if (typeof p !== 'number' || !Number.isFinite(p)) return '—';
  const str = num(p, 2);
  const [intPart, decPart] = str.split('.');
  return `<span class="currency-sign">$</span>${intPart}<span class="price-cents">.${decPart}</span>`;
}

function range24hHTML(mk) {
  const last = mk?.coinbase_last, high = mk?.coinbase_24h_high, low = mk?.coinbase_24h_low;
  if (typeof last !== 'number' || typeof high !== 'number' || typeof low !== 'number' || high <= low) {
    return `<div class="range-24h"><div class="range-labels"><span>24H 区间</span><span>—</span></div><div class="range-track"></div></div>`;
  }
  const pos = Math.max(2, Math.min(98, ((last - low) / (high - low)) * 100));
  return `<div class="range-24h">
    <div class="range-labels"><span>L <strong>$${num(low, 0)}</strong></span><span>H <strong>$${num(high, 0)}</strong></span></div>
    <div class="range-track"><div class="range-fill" style="width:${pos.toFixed(1)}%"></div><div class="range-thumb" style="left:${pos.toFixed(1)}%"></div></div>
    <div class="range-title">24H 价格位置 · ${pos.toFixed(0)}%</div>
  </div>`;
}

function fngColor(v) {
  if (typeof v !== 'number') return 'var(--muted)';
  if (v <= 25) return 'var(--coral)';
  if (v <= 45) return 'var(--amber)';
  if (v <= 65) return 'var(--blue)';
  return 'var(--mint)';
}

function fngLabelZh(v) {
  if (typeof v !== 'number' || !Number.isFinite(v)) return '暂无';
  if (v <= 20) return '极度恐慌';
  if (v <= 40) return '恐慌';
  if (v <= 60) return '中性';
  if (v <= 80) return '贪婪';
  return '极度贪婪';
}

function marketCard(r, m) {
  const mk = m.market || {};
  const prem = mk.coinbase_premium_pct;
  const fund = mk.funding_rate_pct;
  const stChg = mk.stablecoin_7d_chg_pct;
  const stTotal = mk.stablecoin_total_b;
  const fng = mk.fng_value;
  const offshore = typeof mk.offshore_last === 'number' ? `${String(mk.offshore_source || 'OKX').toUpperCase()} $${num(mk.offshore_last, 0)}` : '离岸 —';
  const volRatio = typeof mk.coinbase_vol_ratio_30d === 'number' ? `30D 量比 ${num(mk.coinbase_vol_ratio_30d, 2)}x` : '';

  return cardStart(
    'market',
    `<span class="market-title"><span class="coin-icon">₿</span> BITCOIN / USD · COINBASE</span>`,
    `<div class="market-badges">${volRatio ? `<span class="tiny-badge">${volRatio}</span>` : ''}${m.stale ? '<span class="tiny-badge">快照</span>' : ''}</div>`
  ) +
    `<div class="market-hero-row">
      <div class="market-price-block">
        <div class="market-price number">${formatPriceHTML(mk.coinbase_last)}</div>
        <div class="market-subline"><span>${esc(offshore)}</span><span>·</span><span>稳定币总市值 ${typeof stTotal === 'number' ? '$' + num(stTotal, 2) + 'B' : '—'}</span></div>
      </div>
      ${range24hHTML(mk)}
    </div>
    <div class="telemetry-strip">
      <div class="telemetry-cell">
        <div class="metric-label">Coinbase 溢价</div>
        <div class="metric-value number ${typeof prem === 'number' ? color(prem) : ''}">${pct(prem, 2)}</div>
        <div class="metric-sub">${typeof prem === 'number' ? (prem >= 0 ? '美资买盘占优' : '美资买盘偏弱') : '—'}</div>
      </div>
      <div class="telemetry-cell">
        <div class="metric-label">永续资金费率</div>
        <div class="metric-value number ${typeof fund === 'number' && fund > 0.03 ? 'warn' : ''}">${pct(fund, 4)}</div>
        <div class="metric-sub">${typeof m.locks?.funding_safe === 'boolean' ? (m.locks.funding_safe ? '服务器条件通过' : '服务器条件未通过') : '服务器状态暂无'}</div>
      </div>
      <div class="telemetry-cell">
        <div class="metric-label">稳定币 7D 变化</div>
        <div class="metric-value number ${typeof stChg === 'number' ? color(stChg) : ''}">${pct(stChg, 2)}</div>
        <div class="metric-sub">${typeof mk.stablecoin_7d_chg_b === 'number' ? num(mk.stablecoin_7d_chg_b, 2, true) + 'B' : '—'}</div>
      </div>
      <div class="telemetry-cell">
        <div class="metric-label">恐慌贪婪指数</div>
        <div class="fng-inline">
          <div class="metric-value number" style="margin-top:0">${typeof fng === 'number' ? Math.round(fng) : '—'}</div>
          <div class="fng-bar-wrap"><div class="fng-bar-fill" style="width:${typeof fng === 'number' ? Math.max(4, Math.min(100, fng)) : 0}%;background:${fngColor(fng)}"></div></div>
        </div>
        <div class="metric-sub">${fngLabelZh(fng)}</div>
      </div>
    </div></section>`;
}

function accountCard(r) {
  const a = r?.account;
  const stale = age(r?.generated_at) > 900000;
  return cardStart('account', '模拟账户', `<span class="tiny-badge">${stale && r ? '较旧 · ' : ''}PAPER USD</span>`) +
    `<div class="account-total number">${state.config.hidden ? '••••' : typeof a?.equity === 'number' ? '<span class="currency-sign">$</span>' + money(a.equity) : '—'}</div>
    <div class="account-return number ${color(a?.return_pct)}">${pct(a?.return_pct)}<small>总收益率</small></div>
    <div class="account-spacer"></div>
    <div class="account-metrics">
      <div><div class="metric-label">已实现盈亏</div><div class="metric-value number ${color(a?.realized_pnl)}">${money(a?.realized_pnl, 2, true)}</div></div>
      <div><div class="metric-label">最大回撤</div><div class="metric-value number muted">${pct(a?.drawdown_pct)}</div></div>
    </div></section>`;
}

function emptyPositionsIcon(connected) {
  const stroke = connected ? 'var(--text-secondary)' : '#475569';
  const accent = connected ? 'var(--mint)' : 'var(--muted)';
  return `<svg class="standby-svg" viewBox="0 0 56 56" fill="none" aria-hidden="true">
    <rect x="8" y="13" width="40" height="30" rx="8" stroke="${stroke}" stroke-width="2" stroke-dasharray="4 3"/>
    <path d="M18 28h20" stroke="${accent}" stroke-width="2.5" stroke-linecap="round"/>
    <circle cx="28" cy="28" r="4" fill="#11151b" stroke="${accent}" stroke-width="2.2"/>
    <path d="M28 7v5M28 44v5" stroke="${stroke}" stroke-width="1.8" stroke-linecap="round" opacity="0.6"/>
  </svg>`;
}

function positionsCard(r) {
  const ps = r?.positions;
  let html = cardStart('positions', '当前持仓', Array.isArray(ps) ? `<span class="tiny-badge">${ps.length} 个仓位</span>` : '');
  if (!Array.isArray(ps) || !ps.length) {
    return html + `<div class="holdings-empty">
      <div class="standby-badge">${emptyPositionsIcon(Boolean(ps))}</div>
      <div class="empty-title">${ps ? '当前空仓' : '等待持仓'}</div>
      <div class="empty-sub">${ps ? '暂无进行中的模拟仓位' : '连接快照后自动同步'}</div>
    </div></section>`;
  }
  const pages = Math.ceil(ps.length / 2);
  state.positionPage = Math.max(0, state.positionPage % pages);
  const entries = ps.slice(state.positionPage * 2, state.positionPage * 2 + 2);
  html += '<div class="positions-list">' + entries.map(p => `<div class="position ${entries.length === 1 ? 'single' : ''}">
    <div class="position-head">
      <div class="position-symbol">${esc(String(p.symbol || '—').replace(/(USDT|USDC|USD)$/, ''))}</div>
      <span class="position-side ${p.side === 'Short' ? 'short' : ''}">${p.side === 'Long' ? '做多' : p.side === 'Short' ? '做空' : '—'}</span>
    </div>
    <div class="position-pnl ${color(p.unrealized_pnl)}">
      <span class="position-amount number">${money(p.unrealized_pnl, 2, true)}</span>
      <span class="position-return number">${pct(p.price_move_pct)}</span>
    </div>
    ${entries.length === 1 ? `<div class="position-price">参考标记价 <span class="number">$${num(p.mark_price, 2)}</span></div>` : ''}
  </div>`).join('') + '</div>';
  if (pages > 1) {
    html += `<div class="pagination"><button data-action="position-prev" aria-label="上一页持仓">${icon('back')}</button><span>${state.positionPage + 1} / ${pages}</span><button data-action="position-next" aria-label="下一页持仓">${icon('next')}</button></div>`;
  }
  return html + '</section>';
}

function tradesCard(r) {
  return cardStart('trades', '最近平仓') + `<div class="trade-list">${
    r?.recent_trades?.length
      ? r.recent_trades.slice(0, 3).map(t => `<div class="trade-line"><div>${esc(t.symbol || '—')}<small>${esc(t.close_time_bj || '')}</small></div><span class="number ${color(t.net_pnl)}">${money(t.net_pnl, 2, true)}</span></div>`).join('')
      : '<div class="status-copy muted">暂无平仓记录</div>'
  }</div></section>`;
}

function statusCard(r, m) {
  return cardStart('status', '同步状态') +
    `<div class="status-copy">${state.scenario === 'offline' ? '连接已断开 · 保留上次快照' : state.scenario === 'live' ? '本地仓库快照' : state.scenario === 'imported' ? '本地导入数据' : '演示场景'}</div>
    <div class="account-spacer"></div>
    <div class="settings-state-small">持仓更新 ${time(r?.generated_at)}<br>宏观更新 ${time(m.macro?.generated_at)}<br>正式 App 每 5 分钟检查一次</div></section>`;
}

function brand() {
  return `<div class="identity">
    <div class="brand-mark"><svg viewBox="0 0 30 30" fill="none" aria-hidden="true"><path d="m5 23 9-18h4l8 18h-7l-3-8-4 8Z" fill="var(--mint)"/><circle cx="25" cy="6" r="2.4" fill="var(--amber)"/></svg></div>
    <div class="brand-meta">
      <div class="brand-word">AOYING</div>
      <span class="brand-sep">/</span>
      <div class="page-title">市场与买点监测</div>
    </div>
  </div>`;
}

function isDefaultCockpit(enabledModules) {
  const ids = enabledModules.map(m => m.id).join(',');
  return ids === 'signal,market,account,positions' && enabledModules.every(m => m.span !== 2);
}

function renderDashboard() {
  const r = data(), m = marketModel(r);
  const oldGrid = $('.dashboard-grid');
  if (oldGrid) state.gridScroll = oldGrid.scrollTop;
  const renderers = { signal: signalCard, market: marketCard, positions: positionsCard, account: accountCard, trades: tradesCard, status: statusCard };
  const enabledModules = state.config.modules.filter(x => x.enabled);
  const cockpit = isDefaultCockpit(enabledModules);
  const cards = enabledModules.map(x => {
    let str = renderers[x.id](r, m);
    if (x.span === 2) str = str.replace('class="app-card ', 'class="app-card span-wide ');
    return str;
  }).join('');

  const demo = r?.demo || !['live', 'imported'].includes(state.scenario);
  const source = demo ? '演示数据' : state.scenario === 'imported' ? '本地导入快照' : '私人仓库快照';

  app.innerHTML = `<div class="dashboard">
    <header class="app-header">
      ${brand()}
      <div class="header-right">
        ${demo ? '<span class="pill pill-demo">演示场景</span>' : ''}
        <div class="clock-block">
          <div class="header-date">${new Intl.DateTimeFormat('zh-CN', { timeZone: 'Asia/Shanghai', month: '2-digit', day: '2-digit', weekday: 'long' }).format(new Date())}</div>
          <div class="header-time number">${time(Date.now())}</div>
        </div>
        <button class="icon-button more-button" data-action="menu" aria-label="控制中心">···</button>
      </div>
    </header>
    <div class="dashboard-grid ${cockpit ? 'cockpit-grid' : ''}">${cards}</div>
    <footer class="app-footer">
      <span><i class="source-led ${state.scenario === 'offline' ? 'offline' : ''}"></i>${esc(source)}${state.screensaver ? ' · 屏保预览' : ''}${state.scenario === 'offline' ? ' · 离线缓存' : ''}</span>
      <span>持仓 <strong>${time(r?.generated_at)}</strong> <span class="muted">/</span> 宏观 <strong>${time(m.macro?.generated_at)}</strong></span>
    </footer>
  </div>`;

  const grid = $('.dashboard-grid');
  if (grid && !cockpit) grid.scrollTop = state.gridScroll;
  device.style.setProperty('--type-scale', String(state.config.fontScale));
}

function renderHome() {
  app.innerHTML = `<div class="home-preview">
    <div class="brand-mark">${icon('home')}</div>
    <div class="home-title">桌面模式</div>
    <p>正式 App 会回到 Aerial，这里仅展示切换状态。</p>
    <button class="primary-button" data-action="open-dashboard">打开信息板</button>
    <button class="text-link" data-action="start-screensaver">立即预览屏保 ${icon('next')}</button>
  </div>`;
}

function render() {
  device.dataset.tone = state.config.tone || 'soft';
  if (state.page === 'settings') renderSettings();
  else if (state.page === 'home') renderHome();
  else renderDashboard();
  renderSleep();
  updateCaption();
  fit();
}

function closeOverlay() { overlay.innerHTML = ''; }

function panel(title, body, control = false) {
  overlay.innerHTML = `<div class="modal-shade ${control ? 'control-shade' : ''}" data-action="close-overlay">
    <section class="${control ? 'control-panel' : 'details-panel'}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="modal-heading"><span>${esc(title)}</span><button class="icon-button" data-action="close-overlay" aria-label="关闭">${icon('close')}</button></div>
      ${body}
    </section>
  </div>`;
  const b = overlay.querySelector('button');
  b?.focus({ preventScroll: true });
}

function menu() {
  const items = [
    ['refresh', 'refresh', '刷新数据'],
    ['hide', 'eye', state.config.hidden ? '显示金额' : '隐藏金额'],
    ['settings', 'settings', '设置'],
    ['start-screensaver', 'moon', '屏保预览'],
    ['home', 'home', '返回桌面']
  ];
  panel('控制中心', `<div class="control-actions">${items.map(([a, i, t]) => `<button class="control-action" data-action="${a}">${icon(i)}<span>${t}</span></button>`).join('')}</div>`, true);
}

function signalDetails() {
  const m = marketModel(data());
  const hits = Array.isArray(m.signals?.left_hit_now) ? m.signals.left_hit_now.length : '—';
  const past = Array.isArray(m.signals?.left_hit_24h) ? m.signals.left_hit_24h.length : '—';
  panel('服务器买点结论', `
    <div class="verdict-detail">${esc(m.verdict || '尚未收到买点结论')}</div>
    <div class="details-facts">
      <div class="details-fact">右侧确认<strong>${m.count ?? '—'} / 3</strong></div>
      <div class="details-fact">当前左侧触发<strong>${hits} 项</strong></div>
      <div class="details-fact">24h 左侧触发<strong>${past} 项</strong></div>
    </div>
    <div class="details-meta">
      <span>宏观快照 ${time(m.macro?.generated_at)}${m.stale ? ' · 已超过买点有效期' : ''}</span>
      <span>屏幕仅呈现服务器结论，不在设备上计算交易信号。</span>
    </div>`);
}

function settingsHeader() {
  return `<div class="settings-header">
    <button class="icon-button" data-action="settings-back" aria-label="返回信息板">${icon('back')}</button>
    <h1>设置</h1>
    <button class="primary-button" data-action="settings-save">保存</button>
  </div>
  <nav class="settings-tabs" aria-label="设置分类">${[['appearance', '外观与显示'], ['screen', '屏幕与时间'], ['data', '数据连接'], ['layout', '模块布局']].map(([id, n]) => `<button class="${state.settingsTab === id ? 'active' : ''}" data-action="settings-tab" data-tab="${id}" aria-selected="${state.settingsTab === id}">${n}</button>`).join('')}</nav>`;
}

const switchHTML = (id, checked, label, attrs = '') => `<label class="switch"><input type="checkbox" ${checked ? 'checked' : ''} aria-label="${esc(label)}" ${id ? `data-setting="${id}"` : ''} ${attrs}><span class="switch-track"></span></label>`;
const settingsCard = (title, note, body) => `<section class="settings-card"><h2>${title}</h2>${note ? `<p class="section-note">${note}</p>` : '<div style="height:14px"></div>'}${body}</section>`;

function screenSettings() {
  const c = state.draft;
  const names = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  const schedule = `<div class="schedule-table">${c.windows.map((w, i) => `<div class="schedule-row">
    <label class="schedule-day"><input type="checkbox" ${w.enabled ? 'checked' : ''} data-day="${i}" data-window="enabled"><span>${names[i]}</span></label>
    <input type="time" value="${esc(w.start)}" data-day="${i}" data-window="start" aria-label="${names[i]}亮屏时间">
    <span class="schedule-to">至</span>
    <input type="time" value="${esc(w.end)}" data-day="${i}" data-window="end" aria-label="${names[i]}关屏时间">
  </div>`).join('')}</div>`;
  const manager = `<div class="settings-row"><div>按键与定时<small>单击关闭屏幕，再按唤醒</small></div>${switchHTML('powerEnabled', c.powerEnabled, '按键与定时')}</div>
    <div class="status-line" id="screen-schedule-state">${icon('sun')}${esc(simulationLabel())}</div>
    <div class="settings-action-row"><button class="secondary-button" data-action="stop-management">停止管理</button></div>`;
  const night = `<div class="form-field"><label for="night-minutes">夜间临时亮屏 / 分钟</label><input id="night-minutes" data-setting="nightMinutes" type="number" min="1" max="120" value="${c.nightMinutes}"></div>
    <div class="form-field"><label for="idle-seconds">空闲进入屏保 / 秒</label><input id="idle-seconds" data-setting="idleSeconds" type="number" min="30" max="3600" value="${c.idleSeconds}"></div>
    <div class="form-field"><label for="dream-brightness">屏保亮度 / %</label><input id="dream-brightness" data-setting="brightness" type="number" min="15" max="70" value="${c.brightness}"></div>
    <p class="field-hint">到点仍会关屏；手动操作不取消时间表。</p>`;
  return `<div class="screen-settings-grid">${settingsCard('亮屏时间', '北京时间 · 结束早于开始表示跨午夜', schedule)}<div class="settings-column">${settingsCard('屏幕管理', '', manager)}${settingsCard('夜间与屏保', '', night)}</div></div>`;
}

function dataSettings() {
  const r = data(), m = marketModel(r);
  return `<div class="data-settings-grid"><div class="settings-column">
    ${settingsCard('私人仓库', '正式 App 使用指定仓库的 Contents 只读权限', `
      <div class="repo-name">jiamuho/aoying-paper-sync</div>
      <div class="connection-note">网页读取<strong>本地仓库快照</strong>，不保存 GitHub 令牌。<br>App 确认后，在设备端配置私人仓库连接。</div>
      <div class="form-field"><label>访问令牌</label><input type="password" disabled placeholder="App 确认后在设备配置" aria-label="网页不使用访问令牌"></div>
      <div class="settings-action-row"><button class="secondary-button" data-action="import">${icon('copy')}导入展示 JSON</button><button class="secondary-button" data-action="refresh">${icon('refresh')}重新载入快照</button></div>`)}
    ${settingsCard('演示模式', '内容带有演示标识，不代表真实持仓', `<div class="settings-row"><div>使用演示数据</div>${switchHTML('demo', !['live', 'imported'].includes(state.scenario), '使用演示数据')}</div>`)}
  </div><div class="settings-column">
    ${settingsCard('数据状态', '', `<div class="settings-state-block">${state.scenario === 'offline' ? '断网缓存演示' : state.scenario === 'live' ? '本地仓库快照' : state.scenario === 'imported' ? '本地导入快照' : '演示场景'}</div>
      <div class="settings-state-small">持仓快照 ${time(r?.generated_at)}<br>宏观快照 ${time(m.macro?.generated_at)}<br>检查频率 每 5 分钟<br>宏观状态 ${m.missing ? '尚无信号' : m.stale ? '快照较旧' : m.partial ? '数据不完整' : '正常'}</div>`)}
    ${settingsCard('连接规则', '', `<div class="settings-state-small">断网时保留上次有效数据。<br>缺失值显示“—”，不补成零。<br>买点结论只读取服务器输出。</div>`)}
  </div></div>`;
}

function layoutSettings() {
  const list = `<div class="module-list">${state.draft.modules.map((m, i) => `<div class="module-row">
    <div class="module-name"><span class="module-icon">${icon(m.id)}</span><div>${esc(m.title)}<div class="module-sub">${esc(m.note)}</div></div></div>
    <button class="module-size" data-action="module-span" data-id="${m.id}">${m.span === 2 ? '通栏' : '标准'}</button>
    <div class="module-actions">
      <button class="icon-button" data-action="module-up" data-id="${m.id}" aria-label="上移${m.title}" ${i === 0 ? 'disabled' : ''}>${icon('up')}</button>
      <button class="icon-button" data-action="module-down" data-id="${m.id}" aria-label="下移${m.title}" ${i === state.draft.modules.length - 1 ? 'disabled' : ''}>${icon('down')}</button>
      ${switchHTML('', m.enabled, m.title, `data-module-toggle="${m.id}"`)}
    </div>
  </div>`).join('')}</div>
  <div class="layout-note"><span>默认展示四个重点区域（左决策塔 + 右双区），更多信息按需开启。</span><button class="secondary-button" data-action="reset-layout">恢复默认</button></div>`;

  return settingsCard('显示模块', '默认保持 1280 × 800 一屏总览；调整后可自由排布', list) +
    `<div class="display-preferences">
      ${settingsCard('字号', '主数字始终保持清晰醒目', `<div class="segmented">${[[1, '大字'], [1.12, '更大'], [1.23, '超大']].map(([v, n]) => `<button data-action="draft-font" data-scale="${v}" class="${Number(state.draft.fontScale) === v ? 'active' : ''}">${n}</button>`).join('')}</div>`)}
      ${settingsCard('显示偏好', '', `<div class="settings-row"><div>隐藏金额<small>百分比与方向仍然可见</small></div>${switchHTML('hidden', state.draft.hidden, '隐藏金额')}</div><div class="settings-action-row"><button class="secondary-button" data-action="copy-layout">${icon('copy')}复制预览配置</button></div>`)}
    </div>`;
}

function appearanceSettings() {
  return settingsCard('显示风格','点选即可预览，保存后应用到信息板',`<div class="tone-options">${[['standard','标准','更清晰的文字对比'],['soft','柔和','暖灰文字 · 日常推荐'],['night','夜间','更低亮度 · 暗光环境']].map(([id,title,note])=>`<button data-action="draft-tone" data-tone="${id}" class="tone-option ${state.draft.tone===id?'active':''}" aria-pressed="${state.draft.tone===id}"><span class="tone-sample tone-${id}">Aa</span><strong>${title}</strong><small>${note}</small><span class="tone-check">${state.draft.tone===id?'✓ 已选择':'选择'}</span></button>`).join('')}</div>`)+
    `<div class="display-preferences">${settingsCard('内容字号','调整信息板文字大小',`<div class="segmented">${[[1,'大字'],[1.12,'更大'],[1.23,'超大']].map(([v,n])=>`<button data-action="draft-font" data-scale="${v}" class="${state.draft.fontScale===v?'active':''}">${n}</button>`).join('')}</div>`)}${settingsCard('金额隐私','百分比与方向保持可见',`<div class="settings-row"><div>隐藏金额</div>${switchHTML('hidden',state.draft.hidden,'隐藏金额')}</div>`)}</div>`;
}

function renderSettings() {
  if (!state.draft) state.draft = clone(state.config);
  device.dataset.tone = state.draft.tone || 'soft';
  const body = state.settingsTab === 'appearance' ? appearanceSettings() : state.settingsTab === 'screen' ? screenSettings() : state.settingsTab === 'data' ? dataSettings() : layoutSettings();
  app.innerHTML = `<section class="settings-screen">${settingsHeader()}<div class="settings-body">${body}</div></section>`;
}

function openSettings() {
  closeOverlay();
  state.draft = clone(state.config);
  state.settingsTab = 'appearance';
  state.page = 'settings';
  render();
}

function saveSettings() {
  const c = state.draft;
  try {
    if (state.settingsTab === 'screen') {
      for (const w of c.windows) {
        if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(w.start) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(w.end) || w.start === w.end) {
          throw Error('请检查亮屏时间，开始与结束不能相同');
        }
      }
      if (c.nightMinutes < 1 || c.nightMinutes > 120 || c.idleSeconds < 30 || c.idleSeconds > 3600 || c.brightness < 15 || c.brightness > 70) {
        throw Error('时间或亮度超出可用范围');
      }
    }
    const previouslyOn = state.config.powerEnabled;
    state.config = clone(c);
    persist();
    if (state.settingsTab === 'screen') {
      if (!c.powerEnabled) { state.screenOn = true; state.manualOff = false; state.overrideEnd = null; }
      else if (!previouslyOn && !within(state.simAbsolute)) { state.screenOn = true; state.overrideEnd = state.simAbsolute + c.nightMinutes; }
      renderSleep();
      toast('屏幕偏好已保存 · 仅在网页模拟');
    } else if (state.settingsTab === 'data') {
      const demoBox = document.querySelector('[data-setting="demo"]');
      if (demoBox?.checked && ['live', 'imported'].includes(state.scenario)) setScenario('wait');
      else if (demoBox && !demoBox.checked && !['live', 'imported'].includes(state.scenario)) setScenario('live');
      toast('预览偏好已保存');
    } else {
      toast(state.settingsTab === 'appearance' ? '显示偏好已保存' : '布局已保存');
    }
    renderSettings();
    updateCaption();
  } catch (e) {
    toast(e.message, true);
  }
}

const minutes = s => { const [h, m] = s.split(':').map(Number); return h * 60 + m; };

function within(abs) {
  const week = 10080, t = ((abs % week) + week) % week;
  return state.config.windows.some(w => {
    if (!w.enabled) return false;
    const start = (w.day - 1) * 1440 + minutes(w.start);
    let end = (w.day - 1) * 1440 + minutes(w.end);
    if (end <= start) end += 1440;
    return [t, t + week, t - week].some(x => x >= start && x < end);
  });
}

function simulationLabel() {
  if (!state.config.powerEnabled) return '屏幕管理已停止';
  if (!state.screenOn) return state.manualOff ? '手动熄屏 · 再按唤醒或等下次亮屏' : '夜间时段 · 屏幕关闭';
  if (!within(state.simAbsolute) && state.overrideEnd != null) return `夜间临时亮屏 · 剩余 ${Math.max(0, Math.ceil(state.overrideEnd - state.simAbsolute))} 分钟`;
  return '处于亮屏时段';
}

function advanceTo(next) {
  const previous = within(state.simAbsolute);
  state.simAbsolute = next;
  const nowWithin = within(next);
  if (state.config.powerEnabled) {
    if (!previous && nowWithin) { state.screenOn = true; state.manualOff = false; state.overrideEnd = null; }
    else if (previous && !nowWithin) { state.screenOn = false; state.manualOff = false; state.overrideEnd = null; }
    if (state.overrideEnd != null && next >= state.overrideEnd) { state.overrideEnd = null; if (!nowWithin) state.screenOn = false; }
    if (!nowWithin && state.overrideEnd == null) state.screenOn = false;
  }
  renderSleep();
  updateCaption();
  const el = $('#screen-schedule-state');
  if (el) el.innerHTML = icon('sun') + esc(simulationLabel());
}

function togglePower() {
  closeOverlay();
  if (!state.config.powerEnabled) { toast('屏幕管理已停止，按键测试不生效'); return; }
  if (state.screenOn) { state.screenOn = false; state.manualOff = true; state.overrideEnd = null; }
  else { state.screenOn = true; state.manualOff = false; state.overrideEnd = within(state.simAbsolute) ? null : state.simAbsolute + state.config.nightMinutes; }
  renderSleep();
  updateCaption();
}

function renderSleep() {
  const el = $('#sleep-screen');
  el.hidden = state.screenOn;
  if (!state.screenOn) {
    el.innerHTML = `${icon('power')}<div class="sleep-time">${String(Math.floor((state.simAbsolute % 1440) / 60)).padStart(2, '0')}:${String(state.simAbsolute % 60).padStart(2, '0')}</div><h2>熄屏预览</h2><p>只模拟网页状态，不控制设备</p><button class="secondary-button" data-action="wake-preview">唤醒预览</button>`;
  }
}

function updateCaption() {
  const source = state.scenario === 'live' ? '来源：私人仓库的本地快照' : state.scenario === 'imported' ? '来源：本地导入 JSON' : '演示场景 · 非实时持仓数据';
  $('#preview-source').textContent = source;
  $('#simulation-state').textContent = simulationLabel();
  const t = ((state.simAbsolute % 1440) + 1440) % 1440;
  $('#sim-time').value = `${String(Math.floor(t / 60)).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`;
  $('#scenario').value = state.scenario === 'imported' ? 'live' : state.scenario;
}

function setScenario(s) {
  state.scenario = s;
  state.demoData = !['live', 'imported', 'empty'].includes(s) ? demoSnapshot(s) : null;
  state.positionPage = 0;
  state.gridScroll = 0;
  closeOverlay();
  if (state.page === 'settings') renderSettings();
  else render();
  updateCaption();
}

async function refresh() {
  try {
    const r = await fetch('data/snapshot.json', { cache: 'no-store' });
    if (!r.ok) throw Error('本地快照读取失败');
    state.raw = validate(await r.json());
    if (state.scenario === 'live') render();
    toast('已载入本地仓库快照');
  } catch (e) {
    toast(e.message + '，保留上次数据', true);
  }
}

async function copyConfig() {
  const v = JSON.stringify({ version: 2, ...state.draft }, null, 2);
  try {
    await navigator.clipboard.writeText(v);
    toast('预览配置已复制，不包含账户数据');
  } catch {
    const url = URL.createObjectURL(new Blob([v], { type: 'application/json' })), a = document.createElement('a');
    a.href = url;
    a.download = 'aoying-layout.json';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    toast('已导出布局配置');
  }
}

function fit() {
  const area = $('#stage'), workspace = $('.preview-workspace');
  const spacing = getComputedStyle(workspace);
  const available = workspace.clientWidth - parseFloat(spacing.paddingLeft) - parseFloat(spacing.paddingRight);
  const maxHeight = Math.max(420, window.innerHeight - 170);
  const scale = state.fit ? Math.min(1, available / 1280, maxHeight / 800) : 1;
  device.style.transform = `scale(${scale})`;
  area.style.width = `${1280 * scale}px`;
  area.style.height = `${800 * scale}px`;
  area.classList.toggle('actual-size', !state.fit);
  $('#fit-toggle').textContent = state.fit ? '适应窗口' : '100% 尺寸';
}

document.addEventListener('click', async event => {
  state.lastInteraction = Date.now();
  const el = event.target.closest('[data-action]');
  if (!el) return;
  if (el.classList.contains('modal-shade') && el !== event.target) return;
  const action = el.dataset.action;
  switch (action) {
    case 'menu': menu(); break;
    case 'close-overlay': closeOverlay(); break;
    case 'signal-details': signalDetails(); break;
    case 'refresh': closeOverlay(); await refresh(); break;
    case 'hide': state.config.hidden = !state.config.hidden; persist(); closeOverlay(); render(); break;
    case 'settings': openSettings(); break;
    case 'settings-back': state.page = 'dashboard'; state.draft = null; render(); break;
    case 'settings-tab': state.settingsTab = el.dataset.tab; renderSettings(); break;
    case 'settings-save': saveSettings(); break;
    case 'home': closeOverlay(); state.page = 'home'; state.screensaver = false; render(); break;
    case 'open-dashboard': state.page = 'dashboard'; state.screensaver = false; render(); break;
    case 'start-screensaver': closeOverlay(); state.page = 'dashboard'; state.screensaver = true; render(); toast('屏保预览 · 返回桌面可从菜单操作'); break;
    case 'position-next': state.positionPage++; renderDashboard(); break;
    case 'position-prev': state.positionPage = Math.max(0, state.positionPage - 1); renderDashboard(); break;
    case 'import': $('#json-file').click(); break;
    case 'wake-preview': togglePower(); break;
    case 'stop-management':
      state.config.powerEnabled = false;
      state.draft.powerEnabled = false;
      state.screenOn = true;
      state.manualOff = false;
      state.overrideEnd = null;
      persist();
      renderSettings();
      renderSleep();
      updateCaption();
      toast('已停止网页内的屏幕管理模拟');
      break;
    case 'module-span': {
      const m = state.draft.modules.find(x => x.id === el.dataset.id);
      m.span = m.span === 2 ? 1 : 2;
      renderSettings();
      break;
    }
    case 'module-up':
    case 'module-down': {
      const list = state.draft.modules, i = list.findIndex(x => x.id === el.dataset.id), j = i + (action === 'module-up' ? -1 : 1);
      if (j >= 0 && j < list.length) [list[i], list[j]] = [list[j], list[i]];
      renderSettings();
      break;
    }
    case 'draft-tone': state.draft.tone = el.dataset.tone; renderSettings(); break;
    case 'draft-font': state.draft.fontScale = Number(el.dataset.scale); renderSettings(); break;
    case 'reset-layout': state.draft.modules = structuredClone(modules); state.draft.fontScale = 1; renderSettings(); toast('默认布局已载入，保存后生效'); break;
    case 'copy-layout': await copyConfig(); break;
  }
});

document.addEventListener('change', event => {
  const el = event.target;
  if (el.dataset.setting && state.draft) {
    const k = el.dataset.setting;
    state.draft[k] = el.type === 'checkbox' ? el.checked : el.type === 'number' ? Number(el.value) : el.value;
  }
  if (el.dataset.window && state.draft) {
    state.draft.windows[Number(el.dataset.day)][el.dataset.window] = el.type === 'checkbox' ? el.checked : el.value;
  }
  if (el.dataset.moduleToggle && state.draft) {
    const m = state.draft.modules.find(x => x.id === el.dataset.moduleToggle);
    if (m) m.enabled = el.checked;
  }
});

document.addEventListener('keydown', e => {
  state.lastInteraction = Date.now();
  if (e.key === 'Escape') {
    if (overlay.innerHTML) closeOverlay();
    else if (state.page === 'settings') { state.page = 'dashboard'; state.draft = null; render(); }
  }
});

$('#scenario').addEventListener('change', e => setScenario(e.target.value));
$('#font-size').addEventListener('change', e => {
  state.config.fontScale = Number(e.target.value);
  persist();
  if (state.page === 'settings' && state.draft) state.draft.fontScale = state.config.fontScale;
  render();
});
$('#fit-toggle').addEventListener('click', () => { state.fit = !state.fit; fit(); });
$('#power-test').addEventListener('click', togglePower);
$('#advance-time').addEventListener('click', () => advanceTo(state.simAbsolute + 10));
$('#sim-time').addEventListener('change', e => {
  const t = minutes(e.target.value);
  let next = Math.floor(state.simAbsolute / 1440) * 1440 + t;
  if (next < state.simAbsolute) next += 1440;
  advanceTo(next);
});
$('#import-button').addEventListener('click', () => $('#json-file').click());
$('#json-file').addEventListener('change', async e => {
  const file = e.target.files[0];
  if (!file) return;
  try {
    if (file.size > 1048576) throw Error('文件超过 1 MiB');
    const raw = validate(JSON.parse(await file.text()));
    state.imported = raw;
    state.scenario = 'imported';
    state.positionPage = 0;
    closeOverlay();
    render();
    toast('JSON 已导入，未上传到任何服务');
  } catch (error) {
    toast(error.message + '，原数据保持不变', true);
  }
  e.target.value = '';
});

window.addEventListener('resize', fit);
setInterval(() => {
  const el = $('.header-time');
  if (el) el.textContent = time(Date.now());
  if (state.page === 'home' && state.screenOn && state.config.powerEnabled && Date.now() - state.lastInteraction > state.config.idleSeconds * 1000) {
    state.page = 'dashboard';
    state.screensaver = true;
    render();
  }
}, 1000);
setInterval(() => {
  if (state.page === 'dashboard' && !overlay.innerHTML && state.screenOn) renderDashboard();
}, 30000);

if (!within(state.simAbsolute)) state.overrideEnd = state.simAbsolute + state.config.nightMinutes;
$('#font-size').value = String(state.config.fontScale);
render();
refresh();

window.previewDiagnostics = () => ({
  scenario: state.scenario,
  page: state.page,
  screenOn: state.screenOn,
  manualOff: state.manualOff,
  simulation: simulationLabel(),
  fontScale: state.config.fontScale,
  modules: state.config.modules.map(({ id, enabled, span }) => ({ id, enabled, span })),
  positionPage: state.positionPage
});
