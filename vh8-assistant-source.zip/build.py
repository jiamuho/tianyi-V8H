from pathlib import Path
import subprocess,os,zipfile,json,hashlib
P=Path(__file__).resolve().parent;B=Path(r'D:\kvm\device-audit\ZXV10-S100V8H\20261115-142138');R=B/'validation-20261115'
J=B/'tools/jdk-25.0.5+8/bin';SDK=R/'android-build';R8=R/'runtime-tool/direct-home/r8.jar';LIB=B/'tools/lib/jadx-1.5.6-all.jar';O=P/'build';O.mkdir(exist_ok=True)
def run(args):
 p=subprocess.run(list(map(str,args)),capture_output=True,env={**os.environ,'JAVA_TOOL_OPTIONS':'-Dfile.encoding=UTF-8 -Dsun.stdout.encoding=UTF-8 -Dsun.stderr.encoding=UTF-8'})
 if p.returncode:raise RuntimeError((p.stdout+p.stderr).decode('utf-8','replace'))
 return p.stdout.decode('utf-8','replace')
def dex(sources,name):
 c=O/(name+'-classes');d=O/(name+'-dex');c.mkdir(exist_ok=True);d.mkdir(exist_ok=True)
 run([J/'javac.exe','--release','8','-encoding','UTF-8','-cp',SDK/'android-28.jar','-d',c,*sources])
 run([J/'java.exe','-cp',R8,'com.android.tools.r8.D8','--min-api','28','--lib',SDK/'android-28.jar','--output',d,*c.rglob('*.class')])
 return d/'classes.dex'
power=dex(list((P/'power-src').rglob('*.java'))+[P/'src/local/zxv10/panel/Schedule.java'],'power')
with zipfile.ZipFile(P/'assets/power-agent.jar','w',zipfile.ZIP_DEFLATED) as z:z.write(power,'classes.dex')
app=dex(list((P/'src').rglob('*.java')),'app')
res=O/'res.zip';unsigned=O/'unsigned.apk';apk=P/'VH8-assistant.apk'
run([SDK/'aapt2.exe','compile','--dir',P/'src/res','-o',res]);run([SDK/'aapt2.exe','link','-I',SDK/'android-28.jar','--manifest',P/'src/AndroidManifest.xml','-o',unsigned,'--min-sdk-version','28','--target-sdk-version','28','--auto-add-overlay','-R',res])
names=['aerial.apk','guard.jar','su','dispatch','power_io','power-agent.jar','power-start','home.xml','ota.xml']
manifest={n:hashlib.sha256((P/'assets'/n).read_bytes()).hexdigest() for n in names}
with zipfile.ZipFile(unsigned,'a',zipfile.ZIP_DEFLATED) as z:
 z.write(app,'classes.dex');z.write(P/'assets/guard.jar','assets/guard.jar')
 for n in names:z.write(P/'assets'/n,'assets/payload/'+n)
 z.writestr('assets/payload/manifest.json',json.dumps(manifest))
sign=O/'sign';sign.mkdir(exist_ok=True);run([J/'javac.exe','-cp',LIB,'-d',sign,R/'SignProbe.java',R/'VerifyApk.java']);cp=str(sign)+';'+str(LIB)
run([J/'java.exe','-cp',cp,'SignProbe',R/'homebridge-build/homebridge-signing-key.p12',unsigned,apk])
verification=run([J/'java.exe','-cp',cp,'VerifyApk',apk]);assert 'Android28Verified=true' in verification and '588819f7c29438fdda33abaafcb37375a93ebe10bf54c98b99eef524292f37d2' in verification
(O/'verification.txt').write_text(verification,encoding='utf-8');(O/'payload-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
(O/'result.json').write_text(json.dumps({'apk':str(apk),'sha256':hashlib.sha256(apk.read_bytes()).hexdigest(),'bytes':apk.stat().st_size,'version':24,'includesPortfolioScreenSaver':False},indent=2),encoding='utf-8')
print('VH8_SIGNED_APK_BUILT',flush=True)

