package local.zxv10.panel;
import android.content.*;import android.net.*;import android.os.*;import android.system.Os;
import org.json.*;import java.io.*;import java.nio.channels.*;import java.util.*;
import java.lang.Process;
/** Device-local privileged controller: fixed screen operations, never shell input. */
public final class PowerAgent {
 static LocalSocket boundSocket;static boolean dreamApplied,beforeDream;static ComponentName beforeSleep;static long wakeSequence;static String wakeRecovery="";static PowerManager.WakeLock recoveryHold;
 static final String BASE="/data/local/vh8-power",PKG="local.zxv10.homebridge",REVISION="dream-resume-2";
 static Context context;static PowerManager pm;static JSONObject config;static int appUid;static Process io;static BufferedWriter commands;static boolean grabbed,requestedOff,powerDown,wakeOnRelease,longSent,testAlarm;static long downAt,nightUntil,nextAlarm,testUntil;static String error="",boot;
 static String read(File f)throws Exception{byte[] b=java.nio.file.Files.readAllBytes(f.toPath());if(b.length>65536)throw new IOException("file too large");return new String(b,"UTF-8");}
 static void save()throws Exception{File n=new File(BASE+"/config.new");try(FileOutputStream out=new FileOutputStream(n)){out.write(config.toString().getBytes("UTF-8"));out.getFD().sync();}Os.chmod(n.getPath(),0600);if(!n.renameTo(new File(BASE+"/config.json")))throw new IOException("config rename");}
 static void input(int key)throws Exception{Process p=new ProcessBuilder("/system/bin/input","keyevent",Integer.toString(key)).redirectErrorStream(true).start();if(p.waitFor()!=0)throw new IOException("screen input failed");}
 static void setting(String table,String key,String value)throws Exception{ArrayList<String>a=new ArrayList<>();Collections.addAll(a,"/system/bin/settings",value==null||"null".equals(value)?"delete":"put",table,key);if(value!=null&&!"null".equals(value))a.add(value);Process p=new ProcessBuilder(a).redirectErrorStream(true).start();if(p.waitFor()!=0)throw new IOException("setting failed: "+key);}
 static void applyDream()throws Exception{dreamApplied=false;}
 static void restoreDream()throws Exception{dreamApplied=false;}
 static Object dreams()throws Exception{android.os.IBinder b=(android.os.IBinder)Class.forName("android.os.ServiceManager").getMethod("getService",String.class).invoke(null,"dreams");return Class.forName("android.service.dreams.IDreamManager$Stub").getMethod("asInterface",android.os.IBinder.class).invoke(null,b);}
 static void dreamAction(String method)throws Exception{Object d=dreams();Class.forName("android.service.dreams.IDreamManager").getMethod(method).invoke(d);}
 static ComponentName foreground(){try{android.app.ActivityManager am=(android.app.ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);java.util.List<android.app.ActivityManager.RunningTaskInfo>t=am.getRunningTasks(1);return t.isEmpty()?null:t.get(0).topActivity;}catch(Exception e){return null;}}
 static boolean accountStartup(ComponentName c){return c!=null&&c.getPackageName().equals("com.chinatelecom.accloudbox")&&c.getClassName().equals("cn.com.chinatelecom.account.tv.activity.ZpStartUpActivity");}
 static boolean dreaming(){try{return Boolean.TRUE.equals(Class.forName("android.service.dreams.IDreamManager").getMethod("isDreaming").invoke(dreams()));}catch(Exception e){return false;}}
 static void restoreAfterWake(final long sequence,final ComponentName previous,final boolean resumeDream){
  new Thread(()->{try{
   boolean dreamStarted=false,accountRestored=false;
   for(long wait:new long[]{150,400,750,1250,2000}){
    Thread.sleep(wait);
    synchronized(PowerAgent.class){if(sequence!=wakeSequence||requestedOff)return;}
    if(!pm.isInteractive())continue;
    if(!accountRestored&&!accountStartup(previous)&&accountStartup(foreground())){
     ComponentName target=previous==null?new ComponentName("app.orchard.tv","app.orchard.tv.MainActivity"):previous;
     new ProcessBuilder("/system/bin/am","start","--user","0","-f","0x20000","-n",target.flattenToString()).redirectErrorStream(true).redirectOutput(new File(BASE+"/wake-recovery.log")).start().waitFor();
     accountRestored=true;dreamStarted=false;wakeRecovery="restored previous app after automatic vendor startup";
    }
    if(resumeDream&&!dreamStarted){
     if(!dreaming())dreamAction("dream");
     dreamStarted=true;wakeRecovery="restored information screensaver after power wake";
    }
   }
  }catch(Exception e){wakeRecovery="recovery unavailable";}},"WakeReturn").start();
 }
 static synchronized void display(boolean on)throws Exception{if(!on){beforeSleep=foreground();beforeDream=dreaming();}input(on?224:223);requestedOff=!on;long seq=++wakeSequence;if(on)restoreAfterWake(seq,beforeSleep,beforeDream);System.out.println("DISPLAY "+(on?"ON":"OFF"));}
 static synchronized void send(String s)throws Exception{if(commands!=null){commands.write(s+"\n");commands.flush();}}
 static synchronized void release(){if(commands!=null){try{send("STOP");}catch(Exception ignored){}}commands=null;if(io!=null)io.destroy();io=null;grabbed=false;nightUntil=0;testUntil=0;}
 static synchronized void disable()throws Exception{config.put("enabled",false);save();release();restoreDream();}
 static synchronized void enable()throws Exception{
  if(io!=null&&grabbed)return;
  Process p=new ProcessBuilder(BASE+"/power_io","--run",BASEDevice()).redirectError(new File(BASE+"/io-error.log")).start();
  BufferedReader reader=new BufferedReader(new InputStreamReader(p.getInputStream()));String line;boolean ok=false;long end=SystemClock.elapsedRealtime()+4000;
  while(SystemClock.elapsedRealtime()<end&&(line=reader.readLine())!=null){System.out.println("IO "+line);if("GRABBED".equals(line)){ok=true;break;}}
  if(!ok){p.destroy();throw new IOException("电源输入接管失败");}
  io=p;commands=new BufferedWriter(new OutputStreamWriter(p.getOutputStream()));grabbed=true;config.put("enabled",true);save();send("PING");
  error="";new Thread(()->{try{String s;while((s=reader.readLine())!=null){System.out.println("IO "+s);if(s.startsWith("POWER "))key("POWER 1".equals(s));else if("ALARM_FIRED".equals(s))tick();}}catch(Exception e){synchronized(PowerAgent.class){if(io==p)error=e.toString();}}finally{synchronized(PowerAgent.class){if(io==p){commands=null;io=null;grabbed=false;error="输入工作进程已退出，按键已释放";}}}},"PowerEvents").start();
  if(!Schedule.within(config,System.currentTimeMillis()))nightUntil=System.currentTimeMillis()+config.getInt("nightMinutes")*60000L;rearm();
 }
 static String BASEDevice()throws Exception{
  File root=new File("/sys/class/input");File[] files=root.listFiles();if(files!=null)for(File f:files)if(f.getName().matches("event[0-9]+")){
   File name=new File(f,"device/name");if(name.exists()&&read(name).trim().equals("rk805 pwrkey"))return "/dev/input/"+f.getName();}
  throw new IOException("独立电源设备未找到");
 }
 static synchronized void key(boolean down)throws Exception{
  if(down){powerDown=true;longSent=false;downAt=SystemClock.elapsedRealtime();wakeOnRelease=requestedOff||!pm.isInteractive();}
  else if(powerDown){powerDown=false;if(!longSent){if(wakeOnRelease){display(true);nightUntil=Schedule.within(config,System.currentTimeMillis())?0:System.currentTimeMillis()+config.getInt("nightMinutes")*60000L;}else{nightUntil=0;display(false);}rearm();}}
 }
 static synchronized void rearm()throws Exception{
  long t=Schedule.next(config,System.currentTimeMillis());if(nightUntil>0&&(t==0||nightUntil<t))t=nightUntil;
  nextAlarm=t;if(commands!=null)send("ALARM "+(t/1000)+" "+((t%1000)*1000000));
 }
 static synchronized void tick(){try{
  if(io==null)return;send("PING");long now=System.currentTimeMillis();if(testUntil>0&&SystemClock.elapsedRealtime()>=testUntil){display(true);disable();return;}
  if(powerDown&&!longSent&&SystemClock.elapsedRealtime()-downAt>=800){longSent=true;new Thread(()->{try{new ProcessBuilder("/system/bin/input","keyevent","--longpress","26").start().waitFor();}catch(Exception e){error=e.toString();}},"LongPower").start();}
  if(nextAlarm>0&&now>=nextAlarm){boolean on=Schedule.within(config,now);if(testAlarm){testAlarm=false;display(true);nightUntil=on?0:now+config.getInt("nightMinutes")*60000L;}else if(nightUntil>0&&now>=nightUntil){nightUntil=0;if(!on)display(false);else display(true);}else{nightUntil=0;display(on);}rearm();}
 }catch(Exception e){error=e.toString();try{disable();}catch(Exception ignored){}}}
 static boolean validated(){try{JSONObject g=new JSONObject(read(new File(BASE+"/gates.json")));return g.optBoolean("validated",false)&&android.os.Build.FINGERPRINT.equals(g.optString("fingerprint"));}catch(Exception e){return false;}}
 static boolean allowed(int uid){if(uid==0)return true;if(uid!=appUid)return false;try{android.content.pm.PackageInfo p=context.getPackageManager().getPackageInfo(PKG,android.content.pm.PackageManager.GET_SIGNATURES);if(p.applicationInfo.uid!=uid||p.signatures==null)return false;for(android.content.pm.Signature s:p.signatures){byte[] h=java.security.MessageDigest.getInstance("SHA-256").digest(s.toByteArray());StringBuilder hex=new StringBuilder();for(byte b:h)hex.append(String.format(java.util.Locale.US,"%02x",b&255));if(hex.toString().equals("588819f7c29438fdda33abaafcb37375a93ebe10bf54c98b99eef524292f37d2"))return true;}}catch(Exception ignored){}return false;}
 static synchronized JSONObject handle(JSONObject r,int caller)throws Exception{
  String op=r.getString("op");
  if("ENABLE".equals(op)){if(caller!=0&&!validated())throw new SecurityException("实体按键验收尚未完成");enable();config.put("enabled",true);save();testUntil=0;}
  else if("ENABLE_TEST".equals(op)){if(caller!=0)throw new SecurityException("root test only");int sec=r.getInt("seconds");if(sec<10||sec>900)throw new Exception("test lease range");enable();testUntil=SystemClock.elapsedRealtime()+sec*1000L;config.put("enabled",false);save();}
  else if("RECOVERY_HOLD".equals(op)){if(caller!=0)throw new SecurityException("root recovery only");if(recoveryHold==null)recoveryHold=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"zxv10-panel:recovery");recoveryHold.acquire(45000);}
  else if("DISABLE".equals(op))disable();
  else if("APPLY_DREAM".equals(op))applyDream();
  else if("START_DREAM".equals(op)){if(caller!=0)throw new SecurityException("root test only");dreamAction("dream");}
  else if("STOP_DREAM".equals(op))dreamAction("awaken");
  else if("RESCHEDULE".equals(op))rearm();
  else if("SET_CONFIG".equals(op)){JSONObject c=r.getJSONObject("config");Schedule.validate(c);boolean running=grabbed;c.put("enabled",running);config=c;save();if(running)rearm();}
  else if("SCREEN_OFF".equals(op)){nightUntil=0;display(false);rearm();}
  else if("SCREEN_ON".equals(op)){display(true);nightUntil=Schedule.within(config,System.currentTimeMillis())?0:System.currentTimeMillis()+config.getInt("nightMinutes")*60000L;rearm();}
  else if("TEST_ALARM".equals(op)){if(caller!=0)throw new SecurityException("root test only");int sec=r.getInt("seconds");if(!grabbed||sec<3||sec>60)throw new Exception("test alarm range");testAlarm=true;nextAlarm=System.currentTimeMillis()+sec*1000L;send("ALARM "+(nextAlarm/1000)+" "+((nextAlarm%1000)*1000000));display(false);}
  else if(!"STATUS".equals(op))throw new Exception("未知操作");
  JSONObject s=new JSONObject();s.put("ok",true);s.put("enabled",grabbed);s.put("dreamApplied",dreamApplied);s.put("interactive",pm.isInteractive());s.put("nextAlarm",nextAlarm);s.put("nightUntil",nightUntil);s.put("testRemainingSec",testUntil>0?Math.max(0,(testUntil-SystemClock.elapsedRealtime())/1000):0);s.put("revision",REVISION);s.put("beforeDream",beforeDream);s.put("wakeRecovery",wakeRecovery);s.put("config",config);s.put("error",error);s.put("pid",android.os.Process.myPid());s.put("boot",boot);return s;
 }
 public static void main(String[] args){try{run();}catch(Throwable t){t.printStackTrace();System.exit(1);}}
 static void run()throws Exception{
  if(android.os.Process.myUid()!=0)throw new SecurityException("root required");
  RandomAccessFile lock=new RandomAccessFile(BASE+"/agent.lock","rw");FileLock held=lock.getChannel().tryLock();if(held==null)return;
  Looper.prepareMainLooper();Object at=Class.forName("android.app.ActivityThread").getMethod("systemMain").invoke(null);context=(Context)at.getClass().getMethod("getSystemContext").invoke(at);pm=(PowerManager)context.getSystemService(Context.POWER_SERVICE);
  boot=read(new File("/proc/sys/kernel/random/boot_id")).trim();appUid=Integer.parseInt(read(new File(BASE+"/app-uid")).trim());File cf=new File(BASE+"/config.json");config=cf.exists()?new JSONObject(read(cf)):Schedule.defaults();Schedule.validate(config);boolean auto=config.optBoolean("enabled",false);config.put("enabled",false);
  String path=BASE+"/control.sock";new File(path).delete();boundSocket=new LocalSocket();boundSocket.bind(new LocalSocketAddress(path,LocalSocketAddress.Namespace.FILESYSTEM));LocalServerSocket server=new LocalServerSocket(boundSocket.getFileDescriptor());Os.chown(path,0,appUid);Os.chmod(path,0660);
  Runtime.getRuntime().addShutdownHook(new Thread(()->release()));
  if(auto&&validated())try{enable();nightUntil=0;display(Schedule.within(config,System.currentTimeMillis()));rearm();}catch(Exception e){error=e.toString();save();}
  new Thread(()->{for(;;){tick();try{Thread.sleep(200);}catch(Exception e){return;}}},"PowerTimer").start();
  System.out.println("READY revision="+REVISION+" boot="+boot+" uid="+appUid);
  new Thread(()->{try{serve(server);}catch(Throwable e){e.printStackTrace();System.exit(1);}},"PowerSocket").start();
  Looper.loop();
 }
 static void serve(LocalServerSocket server)throws Exception{
  for(;;){LocalSocket c=server.accept();try{c.setSoTimeout(3000);int uid=c.getPeerCredentials().getUid();if(!allowed(uid))throw new SecurityException("caller UID/signature");
   InputStream in=c.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream();int v;while((v=in.read())!=-1&&v!=10){if(b.size()>=4096)throw new IOException("request too large");b.write(v);}JSONObject response;
   try{response=handle(new JSONObject(b.toString("UTF-8")),uid);}catch(Exception e){response=new JSONObject();response.put("ok",false);response.put("error",e.toString());}
   c.getOutputStream().write((response.toString()+"\n").getBytes("UTF-8"));
  }catch(Exception e){System.out.println("CLIENT_ERROR "+e.getClass().getSimpleName());}finally{c.close();}}
 }
}
