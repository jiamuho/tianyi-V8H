package local.zxv10.panel;
import android.net.*;import java.io.*;import org.json.*;
public final class AgentClient {
 public static void main(String[] args)throws Exception{JSONObject request=new JSONObject();request.put("op",args.length>0?args[0]:"STATUS");if(args.length>1){if("SET_CONFIG".equals(args[0]))request.put("config",new JSONObject(args[1]));else request.put("seconds",Integer.parseInt(args[1]));}LocalSocket s=new LocalSocket();s.connect(new LocalSocketAddress("/data/local/vh8-power/control.sock",LocalSocketAddress.Namespace.FILESYSTEM));s.setSoTimeout(10000);s.getOutputStream().write((request.toString()+"\n").getBytes("UTF-8"));System.out.println(new BufferedReader(new InputStreamReader(s.getInputStream())).readLine());s.close();}
}
