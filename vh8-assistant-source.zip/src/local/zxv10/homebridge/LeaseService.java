package local.zxv10.homebridge;
import android.app.*;
import android.content.*;
import android.os.*;
import android.net.Uri;
import android.util.Log;
import java.io.*;
import java.security.MessageDigest;
import java.util.UUID;
/** Renews a root Binder monitor lease without changing system files. */
public final class LeaseService extends Service {
 private volatile boolean alive; private File dir; private String token,jar;
 public static void openAerial(Context c){try{Intent i=new Intent(Intent.ACTION_MAIN);i.setClassName("app.orchard.tv","app.orchard.tv.MainActivity");i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);c.startActivity(i);}catch(Exception e){Log.e("ZXHomeBridge","Aerial entry failed",e);}}
 private String read(File f)throws IOException{BufferedReader r=new BufferedReader(new FileReader(f));try{return r.readLine();}finally{r.close();}}
 private void lease()throws IOException{File tmp=new File(dir,"lease.tmp");FileWriter w=new FileWriter(tmp);w.write(token+" "+(SystemClock.uptimeMillis()+20000)+"\n");w.close();if(!tmp.renameTo(new File(dir,"lease")))throw new IOException("lease rename failed");}
 private boolean active(){try{String[] p=read(new File(dir,"status")).split(" ");return token.equals(p[0])&&"ACTIVE".equals(p[3])&&SystemClock.uptimeMillis()-Long.parseLong(p[1])<15000;}catch(Exception e){return false;}}
 private void prepare()throws Exception{
  dir=new File(getFilesDir(),"g");if(!dir.isDirectory()&&!dir.mkdir())throw new IOException("guard directory");
  ByteArrayOutputStream bytes=new ByteArrayOutputStream();InputStream in=getAssets().open("guard.jar");byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)bytes.write(buf,0,n);in.close();byte[] data=bytes.toByteArray();
  byte[] hash=MessageDigest.getInstance("SHA-256").digest(data);StringBuilder hex=new StringBuilder();for(byte b:hash)hex.append(String.format("%02x",b&255));jar="g_"+hex.substring(0,8)+".jar";
  File dest=new File(getFilesDir(),jar);if(!dest.exists()){FileOutputStream out=new FileOutputStream(dest);out.write(data);out.close();}
  token=UUID.randomUUID().toString();lease();
 }
 private void launch(){try{
  String command="cd "+getFilesDir().getAbsolutePath()+";CLASSPATH="+jar+" app_process /system/bin local.zxv10.homebridge.HomeGuard g >g/log 2>&1 </dev/null &";
  if(command.length()>245)throw new IllegalStateException("command too long");Bundle b=new Bundle();b.putString("jniServiceSystemCmd",command);
  Bundle result=getContentResolver().call(Uri.parse("content://com.android.zshd.deviceinfo/device_info"),"DEV_QUERY",null,b);Log.i("ZXHomeBridge","GUARD_REQUEST "+result);
 }catch(Exception e){Log.e("ZXHomeBridge","Guard start failed",e);}}
 @Override public void onCreate(){super.onCreate();NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("home_bridge","主页接管",NotificationManager.IMPORTANCE_LOW));
  PendingIntent pi=PendingIntent.getActivity(this,0,new Intent(this,ControlActivity.class),PendingIntent.FLAG_UPDATE_CURRENT);
  startForeground(147,new Notification.Builder(this,"home_bridge").setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("VH8助手").setContentText("主页接管与安卓设置入口").setContentIntent(pi).setOngoing(true).build());
 }
 @Override public int onStartCommand(Intent intent,int flags,int id){
  if(!getSharedPreferences("home",MODE_PRIVATE).getBoolean("enabled",false)){stopSelf();return START_NOT_STICKY;}
  if(!alive){alive=true;new Thread(new Runnable(){public void run(){try{prepare();long last=0;int attempts=0;
   while(alive){lease();PolicyOverlay.maybeStart(LeaseService.this);long now=SystemClock.uptimeMillis();if(!active()&&now-last>10000){if(++attempts>3){Log.e("ZXHomeBridge","Stopped after three failed guard starts");break;}last=now;launch();}else if(active()){attempts=0;BootAdbRestore.startPending(LeaseService.this);}Thread.sleep(5000);}
  }catch(Exception e){Log.e("ZXHomeBridge","Lease service failed",e);}finally{alive=false;stopSelf();}}},"HomeLease").start();}return START_STICKY;
 }
 @Override public void onDestroy(){alive=false;if(dir!=null)new File(dir,"lease").delete();super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
