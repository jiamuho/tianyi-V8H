package local.zxv10.homebridge;
import android.content.*;
import android.os.*;
import android.net.Uri;
import android.provider.Settings;
import android.util.Log;
import java.io.*;
import java.util.concurrent.*;
/** Independent bounded boot recovery, at most one setting write per boot. */
final class BootAdbRestore {
 private static final String GET="/system/bin/settings get global adb_enabled";
 private static final String ENABLE="/system/bin/settings put global adb_enabled 1 && /system/bin/settings get global adb_enabled";
 private static String bootId(){try{BufferedReader r=new BufferedReader(new FileReader("/proc/sys/kernel/random/boot_id"));try{return r.readLine();}finally{r.close();}}catch(Exception e){return null;}}
 static void queue(Context context,String action){
  if(!Intent.ACTION_BOOT_COMPLETED.equals(action))return;
  SharedPreferences p=context.getSharedPreferences("home",Context.MODE_PRIVATE);
  if(!p.getBoolean("restore_adb_on_boot",false))return;
  String id=bootId();if(id==null||id.equals(p.getString("adb_restore_attempt_boot",""))||id.equals(p.getString("adb_restore_finished_boot","")))return;
  if(id.equals(p.getString("adb_restore_pending_boot","")))return;
  p.edit().putString("adb_restore_pending_boot",id).putLong("adb_restore_deadline",SystemClock.elapsedRealtime()+120000).commit();
 }
 static void startPending(Context context){SharedPreferences p=context.getSharedPreferences("home",Context.MODE_PRIVATE);if(p.getBoolean("restore_adb_on_boot",false)&&p.contains("adb_restore_pending_boot"))context.startForegroundService(new Intent(context,BootRecoveryService.class));}
 private static int enabled(Context c){return Settings.Global.getInt(c.getContentResolver(),Settings.Global.ADB_ENABLED,0);}
 private static String request(final Context c,final String command)throws Exception{
  ExecutorService executor=Executors.newSingleThreadExecutor(new ThreadFactory(){public Thread newThread(Runnable r){Thread t=new Thread(r,"BootAdbProvider");t.setDaemon(true);return t;}});
  Future<String> f=executor.submit(new Callable<String>(){public String call(){Bundle b=new Bundle();b.putString("jniServiceSystemCmdResult",command);Bundle reply=c.getContentResolver().call(Uri.parse("content://com.android.zshd.deviceinfo/device_info"),"DEV_QUERY",null,b);return reply==null?"":reply.getString("jniServiceSystemCmdResult","").trim();}});
  try{return f.get(8,TimeUnit.SECONDS);}finally{f.cancel(true);executor.shutdownNow();}
 }
 private static String finish(SharedPreferences p,String id,String result){p.edit().putString("adb_restore_finished_boot",id).putString("adb_restore_result",result).remove("adb_restore_pending_boot").remove("adb_restore_deadline").commit();Log.i("ZXHomeBridge","BOOT_ADB_FINISHED result="+result);return result;}
 static String run(Context c,boolean checkOnly){
  SharedPreferences p=c.getSharedPreferences("home",Context.MODE_PRIVATE);
  if(checkOnly){try{String value=request(c,GET);boolean ready="0".equals(value)||"1".equals(value);Log.i("ZXHomeBridge","BOOT_ADB_CHECK_ONLY ready="+ready+" enabled="+enabled(c));return ready?"调试恢复通道可用；当前调试"+(enabled(c)==1?"已开启":"未开启"):"调试恢复通道暂未就绪";}catch(Exception e){Log.w("ZXHomeBridge","BOOT_ADB_CHECK_ONLY_FAILED",e);return "调试恢复通道检查失败；没有修改调试开关";}}
  String id=bootId();if(id==null||!id.equals(p.getString("adb_restore_pending_boot","")))return "没有待处理的开机恢复";
  long deadline=p.getLong("adb_restore_deadline",0);if(deadline==0)return finish(p,id,"missing_deadline");
  for(int count=0;count<24&&SystemClock.elapsedRealtime()<deadline;count++){
   if(!p.getBoolean("restore_adb_on_boot",false))return finish(p,id,"cancelled");
   if(id.equals(p.getString("adb_restore_attempt_boot","")))return finish(p,id,"attempt_already_recorded");
   if(enabled(c)==1)return finish(p,id,"already_enabled");
   try{
    String ready=request(c,GET);
    if(!"0".equals(ready)&&!"1".equals(ready))Log.i("ZXHomeBridge","BOOT_ADB_WAIT_PROVIDER");
    else{
     if(!p.getBoolean("restore_adb_on_boot",false))return finish(p,id,"cancelled");
     if(enabled(c)==1)return finish(p,id,"already_enabled");
     // Record before the only write. Never repeat an ambiguous write or
     // fight a deliberate manual disable later in this boot.
     if(!p.edit().putString("adb_restore_attempt_boot",id).remove("adb_restore_pending_boot").commit())return "无法记录恢复状态；未发送修改请求";
     request(c,ENABLE);return finish(p,id,enabled(c)==1?"enabled":"write_not_confirmed");
    }
   }catch(TimeoutException e){return finish(p,id,"provider_timeout");}
    catch(InterruptedException e){Thread.currentThread().interrupt();return "恢复检查已停止";}
    catch(Exception e){if(id.equals(p.getString("adb_restore_attempt_boot","")))return finish(p,id,"write_failed_no_retry");Log.w("ZXHomeBridge","BOOT_ADB_WAIT_PROVIDER",e);}
   try{Thread.sleep(5000);}catch(InterruptedException e){Thread.currentThread().interrupt();return "恢复检查已停止";}
  }
  return finish(p,id,"readiness_window_expired");
 }
}
