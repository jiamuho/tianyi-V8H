package local.zxv10.homebridge;
import android.content.*;
public final class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context context,Intent incoming){
  BootAdbRestore.queue(context,incoming.getAction());
  if(context.getSharedPreferences("vh8",0).getBoolean("usbAuto",false))context.startForegroundService(new Intent(context,UsbWatchService.class));
  BootAdbRestore.startPending(context);
  if(context.getSharedPreferences("vh8",0).getBoolean("rootReady",false)&&Vh8Ops.compatible())Vh8JobService.start(context,"boot");
  if(!context.getSharedPreferences("home",Context.MODE_PRIVATE).getBoolean("enabled",false))return;
  Intent service=new Intent(context,LeaseService.class);service.putExtra("boot",Intent.ACTION_BOOT_COMPLETED.equals(incoming.getAction()));context.startForegroundService(service);
 }
}
