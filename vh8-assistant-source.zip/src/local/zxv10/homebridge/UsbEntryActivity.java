package local.zxv10.homebridge;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.hardware.usb.*;
import android.util.Log;
/** Standard USB attachment activity; does not open raw USB devices or write storage. */
public final class UsbEntryActivity extends Activity {
 @Override public void onCreate(Bundle state){super.onCreate(state);UsbDevice device=getIntent().getParcelableExtra(UsbManager.EXTRA_DEVICE);boolean storage=false;
  if(device!=null){storage=device.getDeviceClass()==UsbConstants.USB_CLASS_MASS_STORAGE;for(int i=0;i<device.getInterfaceCount();i++)storage|=device.getInterface(i).getInterfaceClass()==UsbConstants.USB_CLASS_MASS_STORAGE;}
  Log.i("ZXHomeBridge","USB_ENTRY massStorage="+storage);
  Intent control=new Intent(this,ControlActivity.class);control.putExtra("open_file_manager",storage);startActivity(control);finish();
 }
}
