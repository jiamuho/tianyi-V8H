package local.zxv10.homebridge;

import android.content.*;import android.os.*;import android.net.Uri;import org.json.*;
import java.io.*;import java.security.*;import java.util.*;import java.util.concurrent.*;

/** Fixed operations for the owner's verified firmware. No command textbox or exported root service. */
final class Vh8Ops {
 static final String FINGERPRINT="ZTE/rk356x_box_32/rk356x_box_32:9/PI/20260817:user/release-keys";
 static final String HOME="/data/system/ifw/zxv10_factory_home.xml",OTA="/data/system/ifw/vh8_ota.xml";
 final Context c;final File dir;final android.content.SharedPreferences prefs;
 interface Progress {void say(String s);}
 Vh8Ops(Context c){this.c=c;dir=new File(c.getFilesDir(),"vh8");dir.mkdirs();prefs=c.getSharedPreferences("vh8",0);}
 static boolean compatible(){return "ZXV10 S100V8H".equals(Build.MODEL)&&Build.VERSION.SDK_INT==28&&FINGERPRINT.equals(Build.FINGERPRINT);}
 static String q(String s){return "'"+s.replace("'","'\\''")+"'";}
 static String read(File f)throws Exception{try(FileInputStream in=new FileInputStream(f)){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>1048576)throw new IOException("日志超过限制");out.write(b,0,n);}return out.toString("UTF-8");}}
 static void write(File f,String s)throws Exception{try(FileOutputStream out=new FileOutputStream(f)){out.write(s.getBytes("UTF-8"));out.getFD().sync();}}
 static String hash(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[]b=new byte[65536];int n;while((n=in.read(b))!=-1)d.update(b,0,n);}StringBuilder x=new StringBuilder();for(byte b:d.digest())x.append(String.format(Locale.US,"%02x",b&255));return x.toString();}
 static String provider(Context c,String command)throws Exception{if(command.length()>245)throw new IOException("请求长度超出固件限制");ExecutorService e=Executors.newSingleThreadExecutor(r->{Thread t=new Thread(r,"VH8Provider");t.setDaemon(true);return t;});Future<String> f=e.submit(()->{Bundle b=new Bundle();b.putString("jniServiceSystemCmdResult",command);Bundle r=c.getContentResolver().call(Uri.parse("content://com.android.zshd.deviceinfo/device_info"),"DEV_QUERY",null,b);return r==null?"":r.getString("jniServiceSystemCmdResult","");});try{return f.get(10,TimeUnit.SECONDS);}finally{f.cancel(true);e.shutdownNow();}}
 void assets()throws Exception{
  JSONObject manifest;try(InputStream in=c.getAssets().open("payload/manifest.json")){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);manifest=new JSONObject(out.toString("UTF-8"));}
  Iterator<String> keys=manifest.keys();while(keys.hasNext()){String name=keys.next();if(!name.matches("[a-zA-Z0-9_.-]+"))throw new IOException("资源名无效");File f=new File(dir,name);String expected=manifest.getString(name);if(f.exists()&&hash(f).equals(expected))continue;
   File tmp=new File(dir,name+".new");try(InputStream in=c.getAssets().open("payload/"+name);FileOutputStream out=new FileOutputStream(tmp)){byte[]b=new byte[65536];int n;while((n=in.read(b))!=-1)out.write(b,0,n);out.getFD().sync();}if(!hash(tmp).equals(expected)||!tmp.renameTo(f))throw new IOException("资源校验失败："+name);
  }
 }
 String job(String operation,String commands)throws Exception{
  if(!compatible())throw new IOException("此型号或固件未验证，只开放只读信息");
  String pending=prefs.getString("pending","");if(!pending.isEmpty()){File old=new File(pending);String text=old.exists()?read(old):"";if(!text.contains("VH8_EXIT="))throw new IOException("上次任务尚未确认结束，请先查看日志，不要重复执行");}
  String id=UUID.randomUUID().toString();File script=new File(dir,"job-"+id+".sh"),out=new File(dir,"job-"+id+".log");write(out,"");
  String pre="#!/system/bin/sh\numask 077\nexec >"+q(out.getAbsolutePath())+" 2>&1\nfinish(){ code=$?; trap - EXIT; printf '\\nVH8_EXIT=%s\\n' \"$code\"; }\ntrap finish EXIT\nset -e\n[ \"$(id -u)\" = 0 ]\n[ \"$(getprop ro.product.model)\" = 'ZXV10 S100V8H' ]\n[ \"$(getprop ro.build.fingerprint)\" = "+q(FINGERPRINT)+" ]\n";
  write(script,pre+commands+"\n");prefs.edit().putString("pending",out.getAbsolutePath()).putString("lastLog",out.getAbsolutePath()).commit();
  // The provider only starts the owned job. Long installs never hold its Binder thread.
  try{provider(c,"/system/bin/sh "+script.getAbsolutePath()+" >/dev/null 2>&1 </dev/null &");}catch(TimeoutException ambiguous){/* Poll the same job; never resubmit an ambiguous write. */}
  long end=SystemClock.elapsedRealtime()+180000;String log="";
  while(SystemClock.elapsedRealtime()<end){log=read(out);if(log.contains("VH8_EXIT=")){prefs.edit().remove("pending").apply();if(!log.trim().endsWith("VH8_EXIT=0"))throw new IOException("操作未完成，已保留日志\n"+tail(log));return log;}Thread.sleep(500);}
  throw new IOException("结果尚未确认，任务可能仍在运行；请查看日志，不要重复提交");
 }
 static String tail(String s){return s.substring(Math.max(0,s.length()-2500));}
 boolean installed(String pkg){try{c.getPackageManager().getPackageInfo(pkg,0);return true;}catch(Exception e){return false;}}
 String base(){return new File("/data/local/codex-screen/power-agent.jar").exists()?"/data/local/codex-screen":"/data/local/vh8-power";}
 String client(String op){return "CLASSPATH="+base()+"/power-agent.jar app_process /system/bin local.zxv10.panel.AgentClient "+op;}
 JSONObject power()throws Exception{String s=job("power-status",client("STATUS"));int a=s.indexOf('{'),b=s.lastIndexOf('}');if(a<0||b<a)throw new IOException("电源组件尚未安装");JSONObject o=new JSONObject(s.substring(a,b+1));prefs.edit().putString("powerState",o.optBoolean("enabled")?(o.optLong("testRemainingSec")>0?"临时测试中":"已正式启用"):"未启用").apply();return o;}
 String backup()throws Exception{
  if(new android.os.StatFs(dir.getAbsolutePath()).getAvailableBytes()<268435456L)throw new IOException("可用空间不足 256 MiB，请先导出旧备份");
  String dest="/data/local/vh8-backups/"+System.currentTimeMillis();String s="b="+q(dest)+"\nmkdir -p \"$b\"\nchmod 700 \"$b\"\ngetprop >\"$b/device.txt\"\npm list packages -f >\"$b/packages.txt\"\npm list packages -d >\"$b/disabled.txt\"\nsettings list global >\"$b/global.txt\"\nsettings list secure >\"$b/secure.txt\"\nsettings list system >\"$b/system.txt\"\ndumpsys device_policy >\"$b/device-policy.txt\"\n";
  for(String f:new String[]{HOME,OTA,"/data/system/ctcc_permissions.xml",base()+"/config.json",base()+"/gates.json"})s+="if [ -f "+q(f)+" ]; then cp -p "+q(f)+" \"$b/"+f.replace('/','_')+"\"; fi\n";
  s+="for pkg in local.zxv10.homebridge app.orchard.tv cn.dlife.smartcloud.launcher; do\n mkdir -p \"$b/$pkg\"\n pm path \"$pkg\" | sed 's/^package://' | while IFS= read -r apk; do [ -f \"$apk\" ] || continue; cp \"$apk\" \"$b/$pkg/$(basename \"$apk\")\"; done\ndone\nfind \"$b\" -type f ! -name SHA256SUMS.txt -exec sha256sum {} \\; >\"$b/SHA256SUMS.txt\"\necho BACKUP="+dest+"\n";
  job("backup",s);prefs.edit().putString("backup",dest).apply();return dest;
 }
 void ensureBackup()throws Exception{if(prefs.getString("backup","").isEmpty())backup();}
 void root()throws Exception{
  assets();String id=provider(c,"id");if(!id.contains("uid=0"))throw new IOException("厂商 root 通道未通过身份验证");
  ensureBackup();String path=dir.getAbsolutePath();job("root-entry","mkdir -p /data/local/codex-root/jobs\nchmod 700 /data/local/codex-root/jobs\nfor f in su dispatch; do\n if [ ! -e /data/local/codex-root/$f ]; then cp "+q(path)+"/$f /data/local/codex-root/$f; chown 0:0 /data/local/codex-root/$f; chmod 755 /data/local/codex-root/$f; fi\ndone\nid\n");prefs.edit().putBoolean("rootReady",true).apply();
 }
 void install(String file,String pkg)throws Exception{assets();ensureBackup();if(installed(pkg))return;job("install", "pm install -r "+q(new File(dir,file).getAbsolutePath())+"\npm path "+pkg+"\n");if(!installed(pkg))throw new IOException("安装状态尚未确认");}
 void home(boolean on)throws Exception{
  if(on){if(!installed("app.orchard.tv"))throw new IOException("请先安装 Aerial");assets();ensureBackup();job("home-enable","CLASSPATH="+q(new File(dir,"guard.jar").getAbsolutePath())+" app_process /system/bin local.zxv10.homebridge.HomeConfig set\nmkdir -p /data/system/ifw\ncp "+q(new File(dir,"home.xml").getAbsolutePath())+" /data/system/ifw/vh8_home.pending\nchown 1000:1000 /data/system/ifw/vh8_home.pending\nchmod 600 /data/system/ifw/vh8_home.pending\nmv /data/system/ifw/vh8_home.pending "+HOME+"\n");c.getSharedPreferences("home",0).edit().putBoolean("enabled",true).putBoolean("restore_adb_on_boot",true).commit();c.startForegroundService(new Intent(c,LeaseService.class));PolicyOverlay.afterBoot(c);}
  else {ensureBackup();c.getSharedPreferences("home",0).edit().putBoolean("enabled",false).commit();c.stopService(new Intent(c,LeaseService.class));job("home-disable","CLASSPATH="+q(new File(dir,"guard.jar").getAbsolutePath())+" app_process /system/bin local.zxv10.homebridge.HomeConfig clear\nif [ -f "+HOME+" ]; then cp "+HOME+" "+q(prefs.getString("backup","")+"/home-before-disable.xml")+"; rm -f "+HOME+"; fi\n");}
 }
 void adb(boolean on)throws Exception{ensureBackup();if(on){job("adb","old=$(getprop service.adb.tcp.port)\nsetprop service.adb.tcp.port 5555\nsetprop persist.adb.tcp.port 5555\nsettings put global development_settings_enabled 1\nsettings put global adb_enabled 1\nif [ \"$old\" != 5555 ]; then setprop ctl.restart adbd; fi\n");}c.getSharedPreferences("home",0).edit().putBoolean("restore_adb_on_boot",on).commit();if(on)PolicyOverlay.afterBoot(c);}
 void ota(boolean block)throws Exception{
  assets();ensureBackup();String s="mkdir -p /data/local/vh8-state\nchmod 700 /data/local/vh8-state\nif [ ! -f /data/local/vh8-state/ota-previous ]; then settings get global automatic_system_updates >/data/local/vh8-state/ota-previous; fi\n";
  if(block)s+="settings put global automatic_system_updates 0\n";
  else s+="v=$(cat /data/local/vh8-state/ota-previous)\ncase \"$v\" in 0|1) settings put global automatic_system_updates \"$v\";; *) settings delete global automatic_system_updates;; esac\n";
  if(block)s+="mkdir -p /data/system/ifw\ncp "+q(new File(dir,"ota.xml").getAbsolutePath())+" /data/system/ifw/vh8_ota.pending\nchown 1000:1000 /data/system/ifw/vh8_ota.pending\nchmod 600 /data/system/ifw/vh8_ota.pending\nmv /data/system/ifw/vh8_ota.pending "+OTA+"\nam stopservice -n com.ztestb.upgrade/.UpgradeService || true\n";
  else s+="if [ -f "+OTA+" ]; then cp "+OTA+" "+q(prefs.getString("backup","")+"/ota-before-disable.xml")+"; rm -f "+OTA+"; fi\n";
  job("ota",s);String actual=provider(c,"if [ -s /data/system/ifw/vh8_ota.xml ]; then echo VH8_OTA_ON; else echo VH8_OTA_OFF; fi");boolean enabled=actual.contains("VH8_OTA_ON");if(enabled!=block)throw new IOException("升级拦截状态校验失败");prefs.edit().putBoolean("otaBlocked",enabled).apply();
 }
 void preparePower()throws Exception{
  assets();ensureBackup();if(base().equals("/data/local/codex-screen")){prefs.edit().putString("powerBase",base()).apply();return;}
  String a=dir.getAbsolutePath(),b=base();String s="mkdir -p "+b+"\nchmod 755 "+b+"\n";
  for(String f:new String[]{"power_io","power-agent.jar","power-start"}){String name=f.equals("power-start")?"start":f;s+="cp "+q(a+"/"+f)+" "+b+"/"+name+"\nchown 0:0 "+b+"/"+name+"\nchmod 755 "+b+"/"+name+"\n";}
  JSONObject config=local.zxv10.panel.Schedule.defaults();write(new File(dir,"power-config.json"),config.toString());s+="if [ ! -e "+b+"/config.json ]; then cp "+q(a+"/power-config.json")+" "+b+"/config.json; chmod 600 "+b+"/config.json; fi\nprintf '%s' '"+android.os.Process.myUid()+"' >"+b+"/app-uid\nchmod 600 "+b+"/app-uid\nsh "+b+"/start\n";
  job("power-install",s);prefs.edit().putString("powerBase",b).apply();
 }
 void powerTest()throws Exception{preparePower();String log=job("power-test","lines=$(wc -l <"+base()+"/agent.log)\necho LINE=$lines\n"+client("ENABLE_TEST 900"));int at=log.indexOf("LINE=");int end=log.indexOf('\n',at);prefs.edit().putInt("testLine",Integer.parseInt(log.substring(at+5,end).trim())+1).putBoolean("powerTestPending",true).apply();}
 void powerEnable()throws Exception{
  preparePower();JSONObject status=power();boolean accepted=false;if(new File(base()+"/gates.json").exists()){String text=job("power-accept-status","cat "+base()+"/gates.json\n");try{JSONObject g=new JSONObject(text.substring(text.indexOf('{'),text.lastIndexOf('}')+1));accepted=g.optBoolean("validated")&&Build.FINGERPRINT.equals(g.optString("fingerprint"));}catch(Exception ignored){}}
  if(!accepted){
   if(!prefs.getBoolean("powerTestPending",false)||!status.optBoolean("enabled")||status.optLong("testRemainingSec")==0)throw new IOException("请先开始按键测试，并确认短按熄屏和再次唤醒");
   String log=job("power-test-check","tail -n +"+Math.max(1,prefs.getInt("testLine",1))+" "+base()+"/agent.log\n");if(!log.contains("DISPLAY OFF")||!log.contains("DISPLAY ON")||log.split("IO POWER 1",-1).length<3)throw new IOException("尚未记录完整的实体按键熄屏／唤醒，请完成测试后再保存");
   JSONObject g=new JSONObject();g.put("validated",true);g.put("fingerprint",Build.FINGERPRINT);g.put("source","VH8 owner confirmed physical roundtrip");File f=new File(dir,"power-gates.json");write(f,g.toString());job("power-accept","cp "+q(f.getAbsolutePath())+" "+base()+"/gates.json\nchown 0:0 "+base()+"/gates.json\nchmod 600 "+base()+"/gates.json\n");
  }
  job("power-enable",client("ENABLE"));JSONObject after=power();if(!after.optBoolean("enabled")||!after.getJSONObject("config").getBoolean("enabled"))throw new IOException("未确认持久化启用");prefs.edit().putBoolean("powerEnabled",true).putBoolean("powerTestPending",false).apply();PolicyOverlay.afterBoot(c);
 }
 void powerDisable()throws Exception{job("power-disable",client("DISABLE"));prefs.edit().putBoolean("powerEnabled",false).apply();}
 void usbRepair()throws Exception{ensureBackup();job("usb-repair","sm list-disks\nsm list-volumes all\nfor vol in $(sm list-volumes public | awk '$1 ~ /^public:[0-9]+,[0-9]+$/ && $2 == \"unmounted\" {print $1}'); do sm mount \"$vol\"; done\n");prefs.edit().putBoolean("usbAuto",true).apply();c.startForegroundService(new Intent(c,UsbWatchService.class));PolicyOverlay.afterBoot(c);}
 void bootPower()throws Exception{String b=prefs.getString("powerBase","");if(!prefs.getBoolean("powerEnabled",false)||!(b.equals("/data/local/vh8-power")||b.equals("/data/local/codex-screen")))return;job("power-boot","sh "+b+"/start\n");}
 void boot()throws Exception{String boot=read(new File("/proc/sys/kernel/random/boot_id")).trim();if(boot.equals(prefs.getString("bootAttempt","")))return;boolean ready=false;for(int i=0;i<12;i++){try{if(provider(c,"id").contains("uid=0")){ready=true;break;}}catch(Exception ignored){}Thread.sleep(3000);}if(!ready)throw new IOException("启动窗口内 root 通道未就绪，可在界面手动重试");prefs.edit().putString("bootAttempt",boot).commit();PolicyOverlay.afterBoot(c);if(c.getSharedPreferences("home",0).getBoolean("restore_adb_on_boot",false))adb(true);bootPower();}
 void inspect()throws Exception{
  String id=compatible()?provider(c,"id"):"固件未验证";boolean ready=id.contains("uid=0");if(ready){String actual=provider(c,"if [ -s /data/system/ifw/vh8_ota.xml ]; then echo OTA_ON; else echo OTA_OFF; fi");prefs.edit().putBoolean("otaBlocked",actual.contains("OTA_ON")).putBoolean("rootInstalled",provider(c,"if [ -r /data/local/codex-root/su ] && [ -x /data/local/codex-root/dispatch ]; then echo ROOT_INSTALLED; else echo ROOT_ABSENT; fi").contains("ROOT_INSTALLED")).apply();}if(ready&&new File(base()+"/power-agent.jar").exists())try{power();}catch(Exception unavailable){prefs.edit().putString("powerState","组件已存在，状态读取失败").apply();}prefs.edit().putBoolean("rootReady",ready).putString("inspection",Build.MODEL+"\n"+Build.FINGERPRINT+"\nroot 通道："+(ready?"UID 0 已验证":"不可用或未验证")+"\nAerial："+(installed("app.orchard.tv")?"已安装":"未安装")+"\n系统升级："+(prefs.getBoolean("otaBlocked",false)?"已拦截已知升级入口":"未由 VH8 拦截")+"\n桌面："+(c.getSharedPreferences("home",0).getBoolean("enabled",false)?"已接管":"未接管")+"\n电源："+prefs.getString("powerState","未安装或未检查")+"\n备份："+prefs.getString("backup","尚未创建")).apply();
 }
 void execute(String op,Progress progress)throws Exception{
  if(op.equals("inspect")){inspect();return;}
  if(!compatible())throw new IOException("不支持此固件的写入操作");
  if(op.equals("setup")){progress.say("1/5 验证 root 并备份");root();progress.say("2/5 安装 Aerial");install("aerial.apk","app.orchard.tv");progress.say("3/5 修复 USB 接入");usbRepair();progress.say("4/5 启用桌面及 ADB 恢复");home(true);adb(true);progress.say("5/5 拦截已知升级入口");ota(true);prefs.edit().putBoolean("setupDone",true).apply();progress.say("基础初始化完成；请到电源页执行实体按键测试");return;}
  if(op.equals("root"))root();else if(op.equals("backup"))backup();else if(op.equals("aerial"))install("aerial.apk","app.orchard.tv");else if(op.equals("usb-repair"))usbRepair();else if(op.equals("home-on"))home(true);else if(op.equals("home-off"))home(false);else if(op.equals("adb-on"))adb(true);else if(op.equals("adb-off"))adb(false);else if(op.equals("ota-on"))ota(true);else if(op.equals("ota-off"))ota(false);else if(op.equals("power-install"))preparePower();else if(op.equals("power-test"))powerTest();else if(op.equals("power-on"))powerEnable();else if(op.equals("power-off"))powerDisable();else if(op.equals("power-boot"))bootPower();else if(op.equals("boot"))boot();else throw new IOException("未知操作");
 }
}
