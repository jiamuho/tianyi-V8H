package local.zxv10.homebridge;
import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.Toast;
/** Runs without the Home interception service or root controller. */
public final class BootRecoveryService extends Service {
 private Thread worker;
 @Override public void onCreate(){super.onCreate();NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("boot_debug_recovery","开机调试恢复",NotificationManager.IMPORTANCE_LOW));PendingIntent pi=PendingIntent.getActivity(this,148,new Intent(this,ControlActivity.class),PendingIntent.FLAG_UPDATE_CURRENT);startForeground(148,new Notification.Builder(this,"boot_debug_recovery").setSmallIcon(android.R.drawable.ic_menu_manage).setContentTitle("调试恢复与设置入口").setContentText("正在检查；点此可打开开发者选项入口").setContentIntent(pi).setOngoing(true).build());}
 @Override public int onStartCommand(Intent intent,int flags,int startId){if(worker!=null)return START_NOT_STICKY;final boolean checkOnly=intent!=null&&intent.getBooleanExtra("check_only",false);worker=new Thread(new Runnable(){public void run(){final String result=BootAdbRestore.run(BootRecoveryService.this,checkOnly);if(!checkOnly){PolicyOverlay.afterBoot(BootRecoveryService.this);ScreenRecovery.afterBoot(BootRecoveryService.this);}new Handler(Looper.getMainLooper()).post(new Runnable(){public void run(){if(checkOnly)Toast.makeText(BootRecoveryService.this,result,Toast.LENGTH_LONG).show();stopSelf();}});}},"IndependentBootAdb");worker.start();return START_NOT_STICKY;}
 @Override public void onDestroy(){if(worker!=null)worker.interrupt();stopForeground(true);super.onDestroy();}
 @Override public IBinder onBind(Intent intent){return null;}
}
